# Fuel & Mileage Tracker — Setup Guide

Professional Android app (Java, Material Design 3, Room, Firebase, Google Maps).

## 1. Open the project

1. Install [Android Studio](https://developer.android.com/studio) (latest stable).
2. **File → Open** → select the `FuelMilage` folder.
3. Wait for Gradle sync to finish.

## 2. Gradle dependencies (already configured)

Key libraries in `gradle/libs.versions.toml` and `app/build.gradle.kts`:

| Library | Purpose |
|---------|---------|
| Room | Local SQLite database (offline-first) |
| Material 3 | Modern UI |
| MPAndroidChart | Analytics charts |
| Play Services Maps & Location | GPS & petrol pump map |
| Firebase Auth & Firestore | Login & cloud backup |
| WorkManager | Background sync & notifications |
| ViewBinding | Type-safe layouts |

## 3. Google Maps API

1. Go to [Google Cloud Console](https://console.cloud.google.com/).
2. Create a project → enable **Maps SDK for Android**.
3. Create an **API key** and restrict it to your app package `com.example.fuelmilage`.
4. In `app/build.gradle.kts`, replace the placeholder:

```kotlin
manifestPlaceholders["MAPS_API_KEY"] = "YOUR_ACTUAL_KEY_HERE"
```

5. Rebuild and run **More → Nearby petrol pumps**.

**Note:** Nearby stations use demo offsets around your GPS until you integrate [Places API](https://developers.google.com/maps/documentation/places/android-sdk) (optional).

## 4. Firebase (Authentication + Firestore backup)

1. Go to [Firebase Console](https://console.firebase.google.com/).
2. Add an Android app with package name `com.example.fuelmilage`.
3. Download `google-services.json` and place it in the **`app/`** folder (next to `build.gradle.kts`).
4. In Firebase Console enable:
   - **Authentication** → Email/Password
   - **Cloud Firestore** (test mode for development)
5. Sync Gradle — the `google-services` plugin applies automatically when the JSON file exists.

Without `google-services.json`, the app still builds and runs in **offline mode**.

## 5. Live fuel prices (mock / API)

- Default: `app/src/main/assets/mock_fuel_prices.json`
- To use a real API, edit `FuelPriceService.loadRemote()` with your endpoint JSON shape:

```json
{ "petrol": 1.52, "diesel": 1.41, "updatedAtMillis": 1710000000000, "region": "Your city" }
```

## 6. Project structure

```
app/src/main/java/com/example/fuelmilage/
├── activities/      # Screens (Main, Login, Maps, Vehicles, Trips, …)
├── adapters/        # RecyclerView adapters
├── database/        # Room DB, DAOs, seed data
├── firebase/        # Auth & cloud sync
├── fragments/       # Dashboard, History, Statistics, More
├── maps/            # Petrol pump finder & directions
├── models/          # Room entities & DTOs
├── notifications/   # Notification channels
├── repository/      # AppRepository (data access)
├── services/        # WorkManager workers
└── utils/           # Analysis, export, predictions, preferences
```

## 7. Features checklist

| # | Feature | Where |
|---|---------|--------|
| 1 | Nearby petrol pumps + directions | `MapsActivity` |
| 2 | Live fuel prices | `FuelPricesActivity`, dashboard card |
| 3 | AI fuel analysis & efficiency score | `FuelAnalysisEngine`, dashboard |
| 4 | Maintenance reminders | `MaintenanceItem`, `SmartAlertWorker` |
| 5 | Multi-vehicle | `VehiclesActivity`, `Vehicle` entity |
| 6 | Firebase login & backup | `LoginActivity`, `CloudSyncRepository` |
| 7 | Analytics charts | `StatisticsFragment` |
| 8 | PDF & Excel export | `ExportUtils`, More tab |
| 9 | Dark mode | `AppPreferences`, Settings |
| 10 | Smart notifications | `SmartAlertWorker`, Settings toggles |
| 11 | Trip tracking | `TripsActivity` |
| 12 | Driving behavior & eco score | `DrivingBehaviorActivity` |
| 13 | Offline + sync | Room + `SyncWorker` |
| 14 | Mileage prediction | `MileagePredictor`, dashboard |
| 15 | Material UI + bottom nav | `MainActivity`, layouts |

## 8. Run the app

1. Connect a device or start an emulator (API 24+).
2. Click **Run** ▶.
3. On first launch: **Continue offline** or register/sign in.
4. Add fuel entries with the **+** FAB.

## 9. Permissions

Grant **location** for maps and **notifications** (Android 13+) when prompted.

## 10. Troubleshooting

| Issue | Fix |
|-------|-----|
| Map is blank | Set valid Maps API key in `build.gradle.kts` |
| Firebase login fails | Add `google-services.json`, enable Email auth |
| Sync fails | Sign in + internet; check Firestore rules |
| Gradle sync fails | Use JDK 17+, Android Studio latest |

---

**Version 2.0** — All original fuel tracking features are preserved and extended.
