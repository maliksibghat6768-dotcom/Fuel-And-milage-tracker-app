package com.example.fuelmilage.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.fuelmilage.R;
import com.example.fuelmilage.adapters.TripAdapter;
import com.example.fuelmilage.databinding.ActivityTripsBinding;
import com.example.fuelmilage.databinding.DialogTripBinding;
import com.example.fuelmilage.models.Trip;
import com.example.fuelmilage.repository.AppRepository;

import java.util.List;

/**
 * Trip tracking: distance, fuel, cost, duration.
 */
public class TripsActivity extends AppCompatActivity implements TripAdapter.Listener {

    private ActivityTripsBinding binding;
    private AppRepository repository;
    private TripAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityTripsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        repository = AppRepository.get(this);
        adapter = new TripAdapter(this);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this));
        binding.recycler.setAdapter(adapter);

        binding.fabAdd.setOnClickListener(v -> showAddDialog());

        LiveData<List<Trip>> live = repository.observeTripsForActiveVehicle();
        live.observe(this, trips -> {
            adapter.submit(trips);
            binding.textEmpty.setVisibility(trips == null || trips.isEmpty()
                    ? android.view.View.VISIBLE : android.view.View.GONE);
        });
    }

    private void showAddDialog() {
        DialogTripBinding d = DialogTripBinding.inflate(LayoutInflater.from(this));
        new AlertDialog.Builder(this)
                .setTitle(R.string.trip_add)
                .setView(d.getRoot())
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.action_save, (dialog, which) -> {
                    try {
                        String title = text(d.inputTitle);
                        double dist = parse(d.inputDistance);
                        double fuel = parse(d.inputFuel);
                        double cost = parse(d.inputCost);
                        int mins = (int) parse(d.inputDuration);
                        long now = System.currentTimeMillis();
                        Trip trip = new Trip(repository.getActiveVehicleId(),
                                title.isEmpty() ? getString(R.string.trip_untitled) : title,
                                now - mins * 60_000L, now, dist, fuel, cost, mins);
                        repository.insertTrip(trip, id ->
                                Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show());
                    } catch (Exception e) {
                        Toast.makeText(this, R.string.trip_invalid, Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    @Override
    public void onDelete(Trip trip) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_delete_title)
                .setMessage(R.string.dialog_delete_message)
                .setPositiveButton(R.string.action_delete, (d, w) -> repository.deleteTrip(trip, null))
                .setNegativeButton(android.R.string.cancel, null)
                .show();
    }

    private static String text(com.google.android.material.textfield.TextInputLayout layout) {
        return layout.getEditText() != null && layout.getEditText().getText() != null
                ? layout.getEditText().getText().toString().trim() : "";
    }

    private static double parse(com.google.android.material.textfield.TextInputLayout layout) {
        String raw = text(layout).replace(',', '.');
        return Double.parseDouble(raw);
    }
}
