package com.example.fuelmilage.firebase;

import android.content.Context;

import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.Vehicle;
import com.example.fuelmilage.repository.AppRepository;
import com.example.fuelmilage.utils.AppPreferences;
import com.example.fuelmilage.utils.NetworkUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Syncs local Room data to Firestore when user is signed in and online.
 */
public class CloudSyncRepository {

    public interface SyncCallback {
        void onComplete(boolean success, String message);
    }

    private final Context appContext;
    private final AppRepository repo;
    private final AppPreferences prefs;
    private final FirebaseFirestore firestore;
    private final boolean firebaseReady;

    public CloudSyncRepository(Context context) {
        appContext = context.getApplicationContext();
        repo = AppRepository.get(appContext);
        prefs = new AppPreferences(appContext);
        FirebaseFirestore fs = null;
        boolean ready = false;
        try {
            fs = FirebaseFirestore.getInstance();
            ready = true;
        } catch (Exception e) {
            fs = null;
        }
        firestore = fs;
        firebaseReady = ready;
    }

    public void syncIfPossible(SyncCallback callback) {
        if (!firebaseReady || firestore == null) {
            callback.onComplete(false, "Firebase not configured. See SETUP.md.");
            return;
        }
        if (!NetworkUtils.isOnline(appContext)) {
            callback.onComplete(false, "Offline — data saved locally.");
            return;
        }
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            callback.onComplete(false, "Sign in to enable cloud backup.");
            return;
        }
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        repo.getAllFuel(fuel -> repo.getVehicles(vehicles -> repo.io(() -> {
            try {
                Map<String, Object> payload = new HashMap<>();
                payload.put("updatedAt", System.currentTimeMillis());
                payload.put("fuelCount", fuel != null ? fuel.size() : 0);
                firestore.collection("users").document(uid)
                        .collection("backups").document("latest")
                        .set(payload);

                if (fuel != null) {
                    for (FuelEntry e : fuel) {
                        firestore.collection("users").document(uid)
                                .collection("fuel_entries")
                                .document(String.valueOf(e.getId()))
                                .set(entryMap(e));
                    }
                }
                if (vehicles != null) {
                    for (Vehicle v : vehicles) {
                        firestore.collection("users").document(uid)
                                .collection("vehicles")
                                .document(String.valueOf(v.getId()))
                                .set(vehicleMap(v));
                    }
                }
                prefs.setLastSyncMillis(System.currentTimeMillis());
                repo.onMain(() -> callback.onComplete(true, "Cloud backup completed."));
            } catch (Exception ex) {
                repo.onMain(() -> callback.onComplete(false,
                        ex.getMessage() != null ? ex.getMessage() : "Sync failed"));
            }
        })));
    }

    private static Map<String, Object> entryMap(FuelEntry e) {
        Map<String, Object> m = new HashMap<>();
        m.put("dateMillis", e.getDateMillis());
        m.put("litres", e.getLitres());
        m.put("pricePerLitre", e.getPricePerLitre());
        m.put("totalCost", e.getTotalCost());
        m.put("odometerKm", e.getOdometerKm());
        m.put("vehicleId", e.getVehicleId());
        m.put("updatedAtMillis", e.getUpdatedAtMillis());
        return m;
    }

    private static Map<String, Object> vehicleMap(Vehicle v) {
        Map<String, Object> m = new HashMap<>();
        m.put("name", v.getName());
        m.put("model", v.getModel());
        m.put("fuelType", v.getFuelType());
        m.put("active", v.isActive());
        m.put("updatedAtMillis", v.getUpdatedAtMillis());
        return m;
    }
}
