package com.example.fuelmilage.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import com.example.fuelmilage.R;
import com.example.fuelmilage.activities.DrivingBehaviorActivity;
import com.example.fuelmilage.activities.FuelPricesActivity;
import com.example.fuelmilage.activities.MapsActivity;
import com.example.fuelmilage.activities.SettingsActivity;
import com.example.fuelmilage.activities.TripsActivity;
import com.example.fuelmilage.activities.VehiclesActivity;
import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.databinding.FragmentMoreBinding;
import com.example.fuelmilage.firebase.CloudSyncRepository;
import com.example.fuelmilage.firebase.FirebaseAuthHelper;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.models.Trip;
import com.example.fuelmilage.repository.AppRepository;
import com.example.fuelmilage.utils.ExportUtils;
import com.example.fuelmilage.utils.MileageCalculator;

import java.io.File;
import java.util.List;

/**
 * Feature hub: maps, prices, vehicles, trips, driving, sync, export.
 */
public class MoreFragment extends Fragment {

    private FragmentMoreBinding binding;
    private FuelRepository fuelRepository;
    private AppRepository appRepository;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentMoreBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        fuelRepository = FuelRepository.get(requireContext());
        appRepository = AppRepository.get(requireContext());

        FirebaseAuthHelper auth = new FirebaseAuthHelper(requireContext());
        String email = auth.getCurrentEmail();
        binding.textAccount.setText(email != null
                ? getString(R.string.more_signed_in, email)
                : getString(R.string.more_offline_mode));

        binding.rowMaps.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), MapsActivity.class)));
        binding.rowPrices.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), FuelPricesActivity.class)));
        binding.rowVehicles.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), VehiclesActivity.class)));
        binding.rowTrips.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), TripsActivity.class)));
        binding.rowDriving.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), DrivingBehaviorActivity.class)));
        binding.rowSettings.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), SettingsActivity.class)));

        binding.buttonSync.setOnClickListener(v -> {
            binding.buttonSync.setEnabled(false);
            new CloudSyncRepository(requireContext()).syncIfPossible((ok, msg) -> {
                binding.buttonSync.setEnabled(true);
                Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show();
            });
        });

        binding.buttonExportPdf.setOnClickListener(v -> exportPdf());
        binding.buttonExportExcel.setOnClickListener(v -> exportExcel());
    }

    private void exportPdf() {
        fuelRepository.getAllByDateDesc(raw -> {
            List<FuelEntryDisplay> rows = MileageCalculator.buildDisplayList(raw);
            try {
                File file = ExportUtils.exportPdfMonthlyReport(requireContext(), raw, rows);
                shareFile(file, "application/pdf");
            } catch (Exception e) {
                Toast.makeText(requireContext(), R.string.error_export, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void exportExcel() {
        fuelRepository.getAllByDateDesc(raw ->
                appRepository.getTripsForActiveVehicle(trips -> {
                    try {
                        File file = ExportUtils.exportExcel(requireContext(), raw, trips);
                        shareFile(file, "application/vnd.ms-excel");
                    } catch (Exception e) {
                        Toast.makeText(requireContext(), R.string.error_export, Toast.LENGTH_LONG).show();
                    }
                }));
    }

    private void shareFile(File file, String mime) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType(mime);
        share.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(
                requireContext(),
                requireContext().getPackageName() + ".fileprovider",
                file));
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(share, getString(R.string.share_report_title)));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
