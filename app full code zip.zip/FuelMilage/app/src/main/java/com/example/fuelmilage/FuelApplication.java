package com.example.fuelmilage;

import android.app.Application;

import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.notifications.NotificationHelper;
import com.example.fuelmilage.repository.AppRepository;
import com.example.fuelmilage.services.WorkScheduler;
import com.example.fuelmilage.utils.AppPreferences;

/**
 * Application entry: theme, repositories, notifications, background workers.
 */
public class FuelApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        AppPreferences prefs = new AppPreferences(this);
        AppPreferences.applyTheme(prefs.getThemeMode());
        FuelRepository.get(this);
        AppRepository.get(this);
        NotificationHelper.ensureChannels(this);
        WorkScheduler.scheduleAll(this);
    }
}
