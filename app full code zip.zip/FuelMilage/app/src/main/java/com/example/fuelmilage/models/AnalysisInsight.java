package com.example.fuelmilage.models;

/** Single AI-style fuel usage suggestion. */
public class AnalysisInsight {

    private final String title;
    private final String message;
    private final int efficiencyScore;

    public AnalysisInsight(String title, String message, int efficiencyScore) {
        this.title = title;
        this.message = message;
        this.efficiencyScore = efficiencyScore;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public int getEfficiencyScore() {
        return efficiencyScore;
    }
}
