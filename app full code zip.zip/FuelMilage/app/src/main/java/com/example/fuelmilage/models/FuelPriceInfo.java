package com.example.fuelmilage.models;

/** Live (or mock) fuel price snapshot for UI display. */
public class FuelPriceInfo {

    private final double petrolPrice;
    private final double dieselPrice;
    private final long updatedAtMillis;
    private final String region;

    public FuelPriceInfo(double petrolPrice, double dieselPrice, long updatedAtMillis, String region) {
        this.petrolPrice = petrolPrice;
        this.dieselPrice = dieselPrice;
        this.updatedAtMillis = updatedAtMillis;
        this.region = region;
    }

    public double getPetrolPrice() {
        return petrolPrice;
    }

    public double getDieselPrice() {
        return dieselPrice;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public String getRegion() {
        return region;
    }
}
