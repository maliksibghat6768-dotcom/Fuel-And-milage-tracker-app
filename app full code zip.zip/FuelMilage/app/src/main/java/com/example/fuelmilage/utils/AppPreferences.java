package com.example.fuelmilage.utils;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

/**
 * User preferences: maintenance, theme, active vehicle, notifications, sync.
 */
public class AppPreferences {

    public static final int THEME_SYSTEM = 0;
    public static final int THEME_LIGHT = 1;
    public static final int THEME_DARK = 2;

    private static final String PREFS = "fuel_mileage_prefs";
    private static final String KEY_MAINT_BASE_ODOMETER = "maint_base_odometer";
    private static final String KEY_MAINT_INTERVAL_KM = "maint_interval_km";
    private static final String KEY_MAINT_TITLE = "maint_title";
    private static final String KEY_ACTIVE_VEHICLE_ID = "active_vehicle_id";
    private static final String KEY_THEME_MODE = "theme_mode";
    private static final String KEY_NOTIFY_LOW_MILEAGE = "notify_low_mileage";
    private static final String KEY_NOTIFY_REFILL = "notify_refill";
    private static final String KEY_NOTIFY_MAINTENANCE = "notify_maintenance";
    private static final String KEY_NOTIFY_HIGH_SPEND = "notify_high_spend";
    private static final String KEY_REFILL_INTERVAL_DAYS = "refill_interval_days";
    private static final String KEY_LAST_SYNC_MILLIS = "last_sync_millis";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_SKIP_LOGIN = "skip_login";

    private final SharedPreferences prefs;

    public AppPreferences(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public double getMaintenanceBaseOdometerKm() {
        return Double.longBitsToDouble(prefs.getLong(KEY_MAINT_BASE_ODOMETER, Double.doubleToRawLongBits(0)));
    }

    public void setMaintenanceBaseOdometerKm(double km) {
        prefs.edit().putLong(KEY_MAINT_BASE_ODOMETER, Double.doubleToRawLongBits(km)).apply();
    }

    public int getMaintenanceIntervalKm() {
        return prefs.getInt(KEY_MAINT_INTERVAL_KM, 10_000);
    }

    public void setMaintenanceIntervalKm(int km) {
        prefs.edit().putInt(KEY_MAINT_INTERVAL_KM, Math.max(500, km)).apply();
    }

    public String getMaintenanceTitle() {
        return prefs.getString(KEY_MAINT_TITLE, "Service");
    }

    public void setMaintenanceTitle(String title) {
        prefs.edit().putString(KEY_MAINT_TITLE, title == null ? "Service" : title).apply();
    }

    public long getActiveVehicleId() {
        return prefs.getLong(KEY_ACTIVE_VEHICLE_ID, 1L);
    }

    public void setActiveVehicleId(long id) {
        prefs.edit().putLong(KEY_ACTIVE_VEHICLE_ID, id).apply();
    }

    public int getThemeMode() {
        return prefs.getInt(KEY_THEME_MODE, THEME_SYSTEM);
    }

    public void setThemeMode(int mode) {
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply();
        applyTheme(mode);
    }

    public static void applyTheme(int mode) {
        switch (mode) {
            case THEME_LIGHT:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case THEME_DARK:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            default:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }
    }

    public boolean isNotifyLowMileage() {
        return prefs.getBoolean(KEY_NOTIFY_LOW_MILEAGE, true);
    }

    public void setNotifyLowMileage(boolean on) {
        prefs.edit().putBoolean(KEY_NOTIFY_LOW_MILEAGE, on).apply();
    }

    public boolean isNotifyRefill() {
        return prefs.getBoolean(KEY_NOTIFY_REFILL, true);
    }

    public void setNotifyRefill(boolean on) {
        prefs.edit().putBoolean(KEY_NOTIFY_REFILL, on).apply();
    }

    public boolean isNotifyMaintenance() {
        return prefs.getBoolean(KEY_NOTIFY_MAINTENANCE, true);
    }

    public void setNotifyMaintenance(boolean on) {
        prefs.edit().putBoolean(KEY_NOTIFY_MAINTENANCE, on).apply();
    }

    public boolean isNotifyHighSpend() {
        return prefs.getBoolean(KEY_NOTIFY_HIGH_SPEND, true);
    }

    public void setNotifyHighSpend(boolean on) {
        prefs.edit().putBoolean(KEY_NOTIFY_HIGH_SPEND, on).apply();
    }

    public int getRefillIntervalDays() {
        return prefs.getInt(KEY_REFILL_INTERVAL_DAYS, 14);
    }

    public void setRefillIntervalDays(int days) {
        prefs.edit().putInt(KEY_REFILL_INTERVAL_DAYS, Math.max(3, days)).apply();
    }

    public long getLastSyncMillis() {
        return prefs.getLong(KEY_LAST_SYNC_MILLIS, 0);
    }

    public void setLastSyncMillis(long millis) {
        prefs.edit().putLong(KEY_LAST_SYNC_MILLIS, millis).apply();
    }

    public String getUserEmail() {
        return prefs.getString(KEY_USER_EMAIL, null);
    }

    public void setUserEmail(String email) {
        prefs.edit().putString(KEY_USER_EMAIL, email).apply();
    }

    public boolean isSkipLogin() {
        return prefs.getBoolean(KEY_SKIP_LOGIN, false);
    }

    public void setSkipLogin(boolean skip) {
        prefs.edit().putBoolean(KEY_SKIP_LOGIN, skip).apply();
    }
}
