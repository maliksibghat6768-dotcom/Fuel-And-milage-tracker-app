package com.example.fuelmilage.firebase;

import android.content.Context;

import com.example.fuelmilage.utils.AppPreferences;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Email/password authentication wrapper around Firebase Auth.
 * Works offline when Firebase is not configured (no google-services.json).
 */
public class FirebaseAuthHelper {

    public interface AuthCallback {
        void onSuccess();

        void onError(String message);
    }

    private final FirebaseAuth auth;
    private final AppPreferences prefs;
    private final boolean available;

    public FirebaseAuthHelper(Context context) {
        prefs = new AppPreferences(context);
        FirebaseAuth instance = null;
        boolean ok = false;
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context);
            }
            instance = FirebaseAuth.getInstance();
            ok = true;
        } catch (Exception e) {
            instance = null;
        }
        auth = instance;
        available = ok;
    }

    public boolean isAvailable() {
        return available;
    }

    public boolean isLoggedIn() {
        return auth != null && auth.getCurrentUser() != null;
    }

    public String getCurrentEmail() {
        if (auth != null) {
            FirebaseUser user = auth.getCurrentUser();
            if (user != null) {
                return user.getEmail();
            }
        }
        return prefs.getUserEmail();
    }

    public void register(String email, String password, AuthCallback callback) {
        if (!available || auth == null) {
            callback.onError("Firebase not configured. Add google-services.json (see SETUP.md).");
            return;
        }
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        prefs.setUserEmail(email);
                        prefs.setSkipLogin(false);
                        callback.onSuccess();
                    } else {
                        callback.onError(task.getException() != null
                                ? task.getException().getMessage()
                                : "Registration failed");
                    }
                });
    }

    public void login(String email, String password, AuthCallback callback) {
        if (!available || auth == null) {
            callback.onError("Firebase not configured. Add google-services.json (see SETUP.md).");
            return;
        }
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        prefs.setUserEmail(email);
                        prefs.setSkipLogin(false);
                        callback.onSuccess();
                    } else {
                        callback.onError(task.getException() != null
                                ? task.getException().getMessage()
                                : "Login failed");
                    }
                });
    }

    public void logout() {
        if (auth != null) {
            auth.signOut();
        }
        prefs.setUserEmail(null);
    }
}
