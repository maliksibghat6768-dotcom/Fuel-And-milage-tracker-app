package com.example.fuelmilage.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.fuelmilage.models.Trip;

import java.util.List;

@Dao
public interface TripDao {

    @Query("SELECT * FROM trips WHERE vehicleId = :vehicleId ORDER BY startMillis DESC")
    LiveData<List<Trip>> observeByVehicle(long vehicleId);

    @Query("SELECT * FROM trips WHERE vehicleId = :vehicleId ORDER BY startMillis DESC")
    List<Trip> getByVehicle(long vehicleId);

    @Query("SELECT * FROM trips ORDER BY startMillis DESC")
    List<Trip> getAll();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Trip trip);

    @Update
    void update(Trip trip);

    @Delete
    void delete(Trip trip);
}
