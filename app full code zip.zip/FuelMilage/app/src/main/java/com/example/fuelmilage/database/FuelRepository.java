package com.example.fuelmilage.database;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;

import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.repository.AppRepository;
import com.example.fuelmilage.utils.AppPreferences;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Backward-compatible facade over fuel data for existing screens.
 * Delegates to {@link AppRepository} with active-vehicle filtering.
 */
public class FuelRepository {

    private static volatile FuelRepository instance;
    private final FuelEntryDao dao;
    private final AppPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private FuelRepository(Context appContext) {
        dao = AppDatabase.getInstance(appContext).fuelEntryDao();
        prefs = new AppPreferences(appContext);
    }

    public static FuelRepository get(Context context) {
        if (instance == null) {
            synchronized (FuelRepository.class) {
                if (instance == null) {
                    instance = new FuelRepository(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    private long vehicleId() {
        return prefs.getActiveVehicleId();
    }

    public LiveData<List<FuelEntry>> observeAllByDateDesc() {
        return dao.observeByVehicle(vehicleId());
    }

    public void getAllByDateDesc(Callback<List<FuelEntry>> callback) {
        io.execute(() -> {
            List<FuelEntry> list = dao.getByVehicle(vehicleId());
            main.post(() -> callback.onResult(list));
        });
    }

    public void getAllByOdometerAsc(Callback<List<FuelEntry>> callback) {
        io.execute(() -> {
            List<FuelEntry> list = dao.getByVehicleOdometerAsc(vehicleId());
            main.post(() -> callback.onResult(list));
        });
    }

    public void getById(long id, Callback<FuelEntry> callback) {
        io.execute(() -> {
            FuelEntry e = dao.getById(id);
            main.post(() -> callback.onResult(e));
        });
    }

    public void getMaxOdometer(Callback<Double> callback) {
        io.execute(() -> {
            Double max = dao.getMaxOdometerForVehicle(vehicleId());
            main.post(() -> callback.onResult(max));
        });
    }

    public void getMaxOdometerExcluding(long excludeId, Callback<Double> callback) {
        io.execute(() -> {
            Double max = dao.getMaxOdometerExcludingForVehicle(vehicleId(), excludeId);
            main.post(() -> callback.onResult(max));
        });
    }

    public void insert(FuelEntry entry, Callback<Long> callback) {
        entry.setVehicleId(vehicleId());
        entry.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            long id = dao.insert(entry);
            main.post(() -> callback.onResult(id));
        });
    }

    public void update(FuelEntry entry, Runnable done) {
        entry.setVehicleId(vehicleId());
        entry.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            dao.update(entry);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void delete(FuelEntry entry, Runnable done) {
        io.execute(() -> {
            dao.delete(entry);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public interface Callback<T> {
        void onResult(T value);
    }
}
