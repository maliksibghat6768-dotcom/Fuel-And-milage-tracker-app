package com.example.fuelmilage.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;

import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.models.Trip;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Exports fuel data to CSV, Excel-compatible TSV, and PDF monthly reports.
 */
public final class ExportUtils {

    private ExportUtils() {
    }

    public static File exportCsv(Context context, List<FuelEntry> entries) throws IOException {
        File dir = getExportDir(context);
        String name = "fuel_export_" + timestamp() + ".csv";
        File out = new File(dir, name);
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        try (FileWriter w = new FileWriter(out)) {
            w.append("id,date,litres,price_per_litre,total_cost,odometer_km,vehicle_id\n");
            if (entries != null) {
                for (FuelEntry e : entries) {
                    appendFuelRow(w, e, df);
                }
            }
        }
        return out;
    }

    /** Excel opens tab-separated .xls files without extra libraries. */
    public static File exportExcel(Context context, List<FuelEntry> entries, List<Trip> trips) throws IOException {
        File dir = getExportDir(context);
        File out = new File(dir, "fuel_report_" + timestamp() + ".xls");
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        try (FileWriter w = new FileWriter(out)) {
            w.append("Fuel History\n");
            w.append("ID\tDate\tLitres\tPrice/L\tTotal\tOdometer\tVehicle\n");
            if (entries != null) {
                for (FuelEntry e : entries) {
                    w.append(String.valueOf(e.getId())).append('\t');
                    w.append(df.format(new Date(e.getDateMillis()))).append('\t');
                    w.append(String.format(Locale.US, "%.2f", e.getLitres())).append('\t');
                    w.append(String.format(Locale.US, "%.3f", e.getPricePerLitre())).append('\t');
                    w.append(String.format(Locale.US, "%.2f", e.getTotalCost())).append('\t');
                    w.append(String.format(Locale.US, "%.0f", e.getOdometerKm())).append('\t');
                    w.append(String.valueOf(e.getVehicleId())).append('\n');
                }
            }
            w.append("\nTrips\n");
            w.append("Title\tDistance km\tFuel L\tCost\tDuration min\n");
            if (trips != null) {
                for (Trip t : trips) {
                    w.append(t.getTitle()).append('\t');
                    w.append(String.format(Locale.US, "%.1f", t.getDistanceKm())).append('\t');
                    w.append(String.format(Locale.US, "%.2f", t.getFuelLitres())).append('\t');
                    w.append(String.format(Locale.US, "%.2f", t.getCost())).append('\t');
                    w.append(String.valueOf(t.getDurationMinutes())).append('\n');
                }
            }
        }
        return out;
    }

    public static File exportPdfMonthlyReport(Context context,
                                              List<FuelEntry> entries,
                                              List<FuelEntryDisplay> displayRows) throws IOException {
        File dir = getExportDir(context);
        File out = new File(dir, "fuel_report_" + timestamp() + ".pdf");

        double totalCost = MileageCalculator.totalCost(entries);
        double avgMileage = MileageCalculator.averageMileage(displayRows);
        MileagePredictor.Prediction prediction = MileagePredictor.predictNextMonth(entries);

        PdfDocument doc = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = doc.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        Paint titlePaint = new Paint();
        titlePaint.setTextSize(22f);
        titlePaint.setFakeBoldText(true);
        Paint body = new Paint();
        body.setTextSize(14f);

        int y = 48;
        canvas.drawText("Fuel & Mileage Monthly Report", 40, y, titlePaint);
        y += 36;
        canvas.drawText("Generated: " + FormatUtils.formatDateTime(System.currentTimeMillis()), 40, y, body);
        y += 28;
        canvas.drawText("Total fuel cost: " + FormatUtils.formatCurrency(totalCost), 40, y, body);
        y += 22;
        canvas.drawText("Average mileage: " + FormatUtils.formatMileage(avgMileage), 40, y, body);
        y += 22;
        canvas.drawText(prediction.summary, 40, y, body);
        y += 36;
        canvas.drawText("Recent fill-ups:", 40, y, titlePaint);
        y += 24;

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        int count = 0;
        if (entries != null) {
            for (FuelEntry e : entries) {
                if (count >= 12) {
                    break;
                }
                String line = df.format(new Date(e.getDateMillis()))
                        + " — " + FormatUtils.formatLitres(e.getLitres())
                        + " @ " + FormatUtils.formatCurrency(e.getTotalCost());
                canvas.drawText(line, 40, y, body);
                y += 20;
                count++;
            }
        }

        doc.finishPage(page);
        try (FileOutputStream fos = new FileOutputStream(out)) {
            doc.writeTo(fos);
        }
        doc.close();
        return out;
    }

    private static void appendFuelRow(FileWriter w, FuelEntry e, SimpleDateFormat df) throws IOException {
        w.append(String.valueOf(e.getId())).append(',');
        w.append(df.format(new Date(e.getDateMillis()))).append(',');
        w.append(String.format(Locale.US, "%.3f", e.getLitres())).append(',');
        w.append(String.format(Locale.US, "%.3f", e.getPricePerLitre())).append(',');
        w.append(String.format(Locale.US, "%.2f", e.getTotalCost())).append(',');
        w.append(String.format(Locale.US, "%.1f", e.getOdometerKm())).append(',');
        w.append(String.valueOf(e.getVehicleId())).append('\n');
    }

    private static File getExportDir(Context context) {
        File dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        if (dir == null) {
            dir = context.getExternalFilesDir(null);
        }
        if (dir == null) {
            dir = context.getFilesDir();
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    private static String timestamp() {
        return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    }
}
