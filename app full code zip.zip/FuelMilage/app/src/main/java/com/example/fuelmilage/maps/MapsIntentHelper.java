package com.example.fuelmilage.maps;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/**
 * Opens Google Maps for turn-by-turn directions to a petrol pump.
 */
public final class MapsIntentHelper {

    private MapsIntentHelper() {
    }

    public static Intent directionsIntent(double lat, double lng) {
        Uri uri = Uri.parse(String.format("google.navigation:q=%f,%f&mode=d", lat, lng));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");
        return intent;
    }

    public static Intent fallbackBrowserDirections(Context context, double lat, double lng) {
        Uri uri = Uri.parse(String.format("https://www.google.com/maps/dir/?api=1&destination=%f,%f", lat, lng));
        return new Intent(Intent.ACTION_VIEW, uri);
    }
}
