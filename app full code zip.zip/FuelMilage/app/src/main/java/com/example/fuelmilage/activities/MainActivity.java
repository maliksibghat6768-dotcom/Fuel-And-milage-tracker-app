package com.example.fuelmilage.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.fuelmilage.R;
import com.example.fuelmilage.databinding.ActivityMainBinding;
import com.example.fuelmilage.fragments.DashboardFragment;
import com.example.fuelmilage.fragments.HistoryFragment;
import com.example.fuelmilage.fragments.MoreFragment;
import com.example.fuelmilage.fragments.StatisticsFragment;
import com.example.fuelmilage.utils.NetworkUtils;
import com.example.fuelmilage.firebase.CloudSyncRepository;

/**
 * Hosts bottom navigation, toolbar actions, and the add-entry FAB.
 */
public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private ActivityResultLauncher<Intent> addEntryLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);

        addEntryLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> { /* Room LiveData refreshes active screens. */ });

        binding.fabAddEntry.setOnClickListener(v -> {
            Intent i = new Intent(this, AddEditFuelEntryActivity.class);
            addEntryLauncher.launch(i);
        });

        binding.bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment target;
            if (id == R.id.nav_dashboard) {
                target = new DashboardFragment();
                binding.fabAddEntry.show();
            } else if (id == R.id.nav_history) {
                target = new HistoryFragment();
                binding.fabAddEntry.show();
            } else if (id == R.id.nav_statistics) {
                target = new StatisticsFragment();
                binding.fabAddEntry.hide();
            } else if (id == R.id.nav_more) {
                target = new MoreFragment();
                binding.fabAddEntry.hide();
            } else {
                return false;
            }
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, target)
                    .commit();
            return true;
        });

        if (savedInstanceState == null) {
            binding.bottomNav.setSelectedItemId(R.id.nav_dashboard);
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, new DashboardFragment())
                    .commit();
        }

        if (NetworkUtils.isOnline(this)) {
            new CloudSyncRepository(this).syncIfPossible((ok, msg) -> { /* silent */ });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
