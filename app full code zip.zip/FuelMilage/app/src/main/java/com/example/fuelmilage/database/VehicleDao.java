package com.example.fuelmilage.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.fuelmilage.models.Vehicle;

import java.util.List;

@Dao
public interface VehicleDao {

    @Query("SELECT * FROM vehicles ORDER BY name ASC")
    LiveData<List<Vehicle>> observeAll();

    @Query("SELECT * FROM vehicles ORDER BY name ASC")
    List<Vehicle> getAll();

    @Query("SELECT * FROM vehicles WHERE id = :id LIMIT 1")
    Vehicle getById(long id);

    @Query("SELECT * FROM vehicles WHERE active = 1 LIMIT 1")
    Vehicle getActive();

    @Query("UPDATE vehicles SET active = 0")
    void clearActive();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Vehicle vehicle);

    @Update
    void update(Vehicle vehicle);

    @Delete
    void delete(Vehicle vehicle);

    @Query("SELECT COUNT(*) FROM vehicles")
    int count();
}
