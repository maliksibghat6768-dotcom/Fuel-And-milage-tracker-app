package com.example.fuelmilage.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.fuelmilage.models.FuelEntry;

import java.util.List;

@Dao
public interface FuelEntryDao {

    @Query("SELECT * FROM fuel_entries ORDER BY dateMillis DESC")
    LiveData<List<FuelEntry>> observeAllByDateDesc();

    @Query("SELECT * FROM fuel_entries WHERE vehicleId = :vehicleId ORDER BY dateMillis DESC")
    LiveData<List<FuelEntry>> observeByVehicle(long vehicleId);

    @Query("SELECT * FROM fuel_entries ORDER BY dateMillis DESC")
    List<FuelEntry> getAllByDateDesc();

    @Query("SELECT * FROM fuel_entries WHERE vehicleId = :vehicleId ORDER BY dateMillis DESC")
    List<FuelEntry> getByVehicle(long vehicleId);

    @Query("SELECT * FROM fuel_entries ORDER BY odometerKm ASC")
    List<FuelEntry> getAllByOdometerAsc();

    @Query("SELECT * FROM fuel_entries WHERE vehicleId = :vehicleId ORDER BY odometerKm ASC")
    List<FuelEntry> getByVehicleOdometerAsc(long vehicleId);

    @Query("SELECT * FROM fuel_entries WHERE id = :id LIMIT 1")
    FuelEntry getById(long id);

    @Query("SELECT MAX(odometerKm) FROM fuel_entries")
    Double getMaxOdometer();

    @Query("SELECT MAX(odometerKm) FROM fuel_entries WHERE vehicleId = :vehicleId")
    Double getMaxOdometerForVehicle(long vehicleId);

    @Query("SELECT MAX(odometerKm) FROM fuel_entries WHERE id != :excludeId")
    Double getMaxOdometerExcluding(long excludeId);

    @Query("SELECT MAX(odometerKm) FROM fuel_entries WHERE vehicleId = :vehicleId AND id != :excludeId")
    Double getMaxOdometerExcludingForVehicle(long vehicleId, long excludeId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(FuelEntry entry);

    @Update
    void update(FuelEntry entry);

    @Delete
    void delete(FuelEntry entry);

    @Query("DELETE FROM fuel_entries WHERE id = :id")
    void deleteById(long id);
}
