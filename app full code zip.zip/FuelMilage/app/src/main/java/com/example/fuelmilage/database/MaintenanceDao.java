package com.example.fuelmilage.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.fuelmilage.models.MaintenanceItem;

import java.util.List;

@Dao
public interface MaintenanceDao {

    @Query("SELECT * FROM maintenance_items WHERE vehicleId = :vehicleId AND enabled = 1")
    LiveData<List<MaintenanceItem>> observeEnabled(long vehicleId);

    @Query("SELECT * FROM maintenance_items WHERE vehicleId = :vehicleId AND enabled = 1")
    List<MaintenanceItem> getEnabled(long vehicleId);

    @Query("SELECT * FROM maintenance_items ORDER BY vehicleId, type")
    List<MaintenanceItem> getAll();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(MaintenanceItem item);

    @Update
    void update(MaintenanceItem item);

    @Delete
    void delete(MaintenanceItem item);
}
