package com.example.fuelmilage.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;

import com.example.fuelmilage.R;
import com.example.fuelmilage.activities.FuelPricesActivity;
import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.databinding.FragmentDashboardBinding;
import com.example.fuelmilage.models.AnalysisInsight;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.models.FuelPriceInfo;
import com.example.fuelmilage.utils.AppPreferences;
import com.example.fuelmilage.utils.FormatUtils;
import com.example.fuelmilage.utils.FuelAnalysisEngine;
import com.example.fuelmilage.utils.FuelPriceService;
import com.example.fuelmilage.utils.MileageCalculator;
import com.example.fuelmilage.utils.MileagePredictor;

import java.util.List;

/**
 * Overview cards, AI insights, fuel prices, and predictions.
 */
public class DashboardFragment extends Fragment {

    private FragmentDashboardBinding binding;
    private FuelRepository repository;
    private AppPreferences prefs;
    private final FuelPriceService priceService = new FuelPriceService();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        repository = FuelRepository.get(requireContext());
        prefs = new AppPreferences(requireContext());

        binding.cardFuelPrices.setOnClickListener(v ->
                startActivity(new Intent(requireContext(), FuelPricesActivity.class)));

        loadFuelPrices();

        LiveData<List<FuelEntry>> live = repository.observeAllByDateDesc();
        live.observe(getViewLifecycleOwner(), this::render);
    }

    private void loadFuelPrices() {
        priceService.fetch(requireContext(), new FuelPriceService.Callback() {
            @Override
            public void onResult(FuelPriceInfo info) {
                if (binding == null) {
                    return;
                }
                long updated = info.getUpdatedAtMillis() > 0
                        ? info.getUpdatedAtMillis() : System.currentTimeMillis();
                binding.textFuelPricesSnippet.setText(getString(
                        R.string.dashboard_fuel_prices_snippet,
                        FormatUtils.formatCurrency(info.getPetrolPrice()),
                        FormatUtils.formatCurrency(info.getDieselPrice()),
                        FormatUtils.formatDateTime(updated)));
            }

            @Override
            public void onError(String message) {
                if (binding != null) {
                    binding.textFuelPricesSnippet.setText(R.string.fuel_prices_unavailable);
                }
            }
        });
    }

    private void render(List<FuelEntry> raw) {
        List<FuelEntryDisplay> rows = MileageCalculator.buildDisplayList(raw);
        double avgMileage = MileageCalculator.averageMileage(rows);
        double totalCost = MileageCalculator.totalCost(raw);
        double totalLitres = MileageCalculator.totalLitres(raw);
        double distance = MileageCalculator.totalDistanceSpan(raw);

        binding.textStatAvgMileage.setText(FormatUtils.formatMileage(avgMileage));
        binding.textStatTotalCost.setText(FormatUtils.formatCurrency(totalCost));
        binding.textStatTotalFuel.setText(FormatUtils.formatLitres(totalLitres));
        binding.textStatTotalDistance.setText(FormatUtils.formatKm(distance));

        AnalysisInsight insight = FuelAnalysisEngine.analyze(rows);
        binding.textAiTitle.setText(insight.getTitle());
        binding.textAiMessage.setText(insight.getMessage());
        binding.textEfficiencyScore.setText(getString(R.string.dashboard_efficiency_score,
                insight.getEfficiencyScore()));

        MileagePredictor.Prediction prediction = MileagePredictor.predictNextMonth(raw);
        binding.textPrediction.setText(prediction.summary);

        boolean drop = MileageCalculator.hasMileageDropWarning(rows);
        binding.bannerMileageDrop.setVisibility(drop ? View.VISIBLE : View.GONE);

        double maxOdo = 0;
        if (raw != null) {
            for (FuelEntry e : raw) {
                maxOdo = Math.max(maxOdo, e.getOdometerKm());
            }
        }

        double base = prefs.getMaintenanceBaseOdometerKm();
        int interval = prefs.getMaintenanceIntervalKm();
        if (base <= 0 || maxOdo <= 0) {
            binding.bannerMaintenance.setVisibility(View.VISIBLE);
            binding.textMaintenanceMessage.setText(R.string.dashboard_maint_hint);
        } else {
            double nextDue = base + interval;
            double remaining = nextDue - maxOdo;
            binding.bannerMaintenance.setVisibility(View.VISIBLE);
            if (remaining <= 500) {
                binding.textMaintenanceMessage.setText(getString(R.string.dashboard_maint_due,
                        prefs.getMaintenanceTitle()));
            } else {
                binding.textMaintenanceMessage.setText(
                        getString(R.string.dashboard_maint_ok, FormatUtils.formatKm(remaining),
                                prefs.getMaintenanceTitle()));
            }
        }

        if (raw == null || raw.isEmpty()) {
            binding.textEmptyHint.setVisibility(View.VISIBLE);
        } else {
            binding.textEmptyHint.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
