package com.example.fuelmilage.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fuelmilage.databinding.ItemTripBinding;
import com.example.fuelmilage.models.Trip;
import com.example.fuelmilage.utils.FormatUtils;

import java.util.ArrayList;
import java.util.List;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.Holder> {

    public interface Listener {
        void onDelete(Trip trip);
    }

    private final Listener listener;
    private List<Trip> items = new ArrayList<>();

    public TripAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Trip> trips) {
        items = trips != null ? trips : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(ItemTripBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.bind(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class Holder extends RecyclerView.ViewHolder {
        private final ItemTripBinding binding;

        Holder(ItemTripBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(Trip trip) {
            binding.textTitle.setText(trip.getTitle());
            binding.textDetails.setText(String.format("%s • %s • %d min",
                    FormatUtils.formatKm(trip.getDistanceKm()),
                    FormatUtils.formatCurrency(trip.getCost()),
                    trip.getDurationMinutes()));
            binding.textFuel.setText(FormatUtils.formatLitres(trip.getFuelLitres()));
            binding.buttonDelete.setOnClickListener(v -> listener.onDelete(trip));
        }
    }
}
