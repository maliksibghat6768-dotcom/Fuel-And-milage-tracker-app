package com.example.fuelmilage.models;

/**
 * UI-ready row combining a stored {@link FuelEntry} with computed segment distance and mileage.
 */
public class FuelEntryDisplay {

    private final FuelEntry entry;
    /** Distance since previous fill-up by odometer order (km). */
    private final double distanceKm;
    /** km per litre for this segment; 0 if not computable. */
    private final double mileageKmPerLitre;

    public FuelEntryDisplay(FuelEntry entry, double distanceKm, double mileageKmPerLitre) {
        this.entry = entry;
        this.distanceKm = distanceKm;
        this.mileageKmPerLitre = mileageKmPerLitre;
    }

    public FuelEntry getEntry() {
        return entry;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public double getMileageKmPerLitre() {
        return mileageKmPerLitre;
    }
}
