package com.example.fuelmilage.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/** Basic driving behavior log for eco-score calculation. */
@Entity(tableName = "driving_sessions")
public class DrivingSession {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long vehicleId;
    private long dateMillis;
    private int harshBrakingCount;
    private int rapidAccelerationCount;
    private int highSpeedAlerts;
    private int ecoScore;
    private String notes;
    private long updatedAtMillis;

    public DrivingSession() {
    }

    @Ignore
    public DrivingSession(long vehicleId, long dateMillis,
                          int harshBrakingCount, int rapidAccelerationCount,
                          int highSpeedAlerts, int ecoScore, String notes) {
        this.vehicleId = vehicleId;
        this.dateMillis = dateMillis;
        this.harshBrakingCount = harshBrakingCount;
        this.rapidAccelerationCount = rapidAccelerationCount;
        this.highSpeedAlerts = highSpeedAlerts;
        this.ecoScore = ecoScore;
        this.notes = notes;
        this.updatedAtMillis = System.currentTimeMillis();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(long vehicleId) {
        this.vehicleId = vehicleId;
    }

    public long getDateMillis() {
        return dateMillis;
    }

    public void setDateMillis(long dateMillis) {
        this.dateMillis = dateMillis;
    }

    public int getHarshBrakingCount() {
        return harshBrakingCount;
    }

    public void setHarshBrakingCount(int harshBrakingCount) {
        this.harshBrakingCount = harshBrakingCount;
    }

    public int getRapidAccelerationCount() {
        return rapidAccelerationCount;
    }

    public void setRapidAccelerationCount(int rapidAccelerationCount) {
        this.rapidAccelerationCount = rapidAccelerationCount;
    }

    public int getHighSpeedAlerts() {
        return highSpeedAlerts;
    }

    public void setHighSpeedAlerts(int highSpeedAlerts) {
        this.highSpeedAlerts = highSpeedAlerts;
    }

    public int getEcoScore() {
        return ecoScore;
    }

    public void setEcoScore(int ecoScore) {
        this.ecoScore = ecoScore;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public void setUpdatedAtMillis(long updatedAtMillis) {
        this.updatedAtMillis = updatedAtMillis;
    }
}
