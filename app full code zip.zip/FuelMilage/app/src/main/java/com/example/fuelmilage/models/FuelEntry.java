package com.example.fuelmilage.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/**
 * Persisted fuel fill-up record. Distance and mileage are derived from odometer order
 * when entries are loaded (see {@link com.example.fuelmilage.utils.MileageCalculator}).
 */
@Entity(tableName = "fuel_entries")
public class FuelEntry {

    @PrimaryKey(autoGenerate = true)
    private long id;

    /** Fill-up date/time in milliseconds since epoch. */
    private long dateMillis;

    private double litres;
    private double pricePerLitre;
    private double totalCost;
    /** Vehicle odometer reading in kilometres at this fill-up. */
    private double odometerKm;
    /** Links entry to a {@link Vehicle}; default vehicle id is 1. */
    private long vehicleId = 1;
    private long updatedAtMillis;

    public FuelEntry() {
    }

    @Ignore
    public FuelEntry(long dateMillis, double litres, double pricePerLitre, double totalCost, double odometerKm) {
        this.id = 0;
        this.dateMillis = dateMillis;
        this.litres = litres;
        this.pricePerLitre = pricePerLitre;
        this.totalCost = totalCost;
        this.odometerKm = odometerKm;
        this.vehicleId = 1;
        this.updatedAtMillis = System.currentTimeMillis();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getDateMillis() {
        return dateMillis;
    }

    public void setDateMillis(long dateMillis) {
        this.dateMillis = dateMillis;
    }

    public double getLitres() {
        return litres;
    }

    public void setLitres(double litres) {
        this.litres = litres;
    }

    public double getPricePerLitre() {
        return pricePerLitre;
    }

    public void setPricePerLitre(double pricePerLitre) {
        this.pricePerLitre = pricePerLitre;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public double getOdometerKm() {
        return odometerKm;
    }

    public void setOdometerKm(double odometerKm) {
        this.odometerKm = odometerKm;
    }

    public long getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(long vehicleId) {
        this.vehicleId = vehicleId;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public void setUpdatedAtMillis(long updatedAtMillis) {
        this.updatedAtMillis = updatedAtMillis;
    }
}
