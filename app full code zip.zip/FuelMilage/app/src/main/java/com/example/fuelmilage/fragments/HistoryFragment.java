package com.example.fuelmilage.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.FileProvider;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.fuelmilage.R;
import com.example.fuelmilage.activities.AddEditFuelEntryActivity;
import com.example.fuelmilage.adapters.FuelEntryAdapter;
import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.databinding.FragmentHistoryBinding;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.utils.ExportUtils;
import com.example.fuelmilage.utils.FormatUtils;
import com.example.fuelmilage.utils.MileageCalculator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Searchable history with edit/delete and CSV export.
 */
public class HistoryFragment extends Fragment implements FuelEntryAdapter.Listener {

    private FragmentHistoryBinding binding;
    private FuelRepository repository;
    private FuelEntryAdapter adapter;
    private List<FuelEntryDisplay> fullRows = new ArrayList<>();
    private ActivityResultLauncher<Intent> editLauncher;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        editLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> { /* LiveData refresh */ });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHistoryBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        repository = FuelRepository.get(requireContext());
        adapter = new FuelEntryAdapter(this);
        binding.recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.recycler.setAdapter(adapter);

        requireActivity().addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menuInflater.inflate(R.menu.menu_history, menu);
                MenuItem searchItem = menu.findItem(R.id.action_search);
                SearchView searchView = (SearchView) searchItem.getActionView();
                if (searchView != null) {
                    searchView.setQueryHint(getString(R.string.search_hint));
                    searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                        @Override
                        public boolean onQueryTextSubmit(String query) {
                            applyFilter(query);
                            return true;
                        }

                        @Override
                        public boolean onQueryTextChange(String newText) {
                            applyFilter(newText);
                            return true;
                        }
                    });
                }
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.action_export_csv) {
                    exportCsv();
                    return true;
                }
                return false;
            }
        }, getViewLifecycleOwner(), Lifecycle.State.RESUMED);

        LiveData<List<FuelEntry>> live = repository.observeAllByDateDesc();
        live.observe(getViewLifecycleOwner(), this::render);
    }

    private void render(List<FuelEntry> raw) {
        fullRows = MileageCalculator.buildDisplayList(raw);
        adapter.submit(fullRows);
        boolean empty = fullRows.isEmpty();
        binding.textEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        binding.recycler.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    private void applyFilter(String query) {
        if (query == null || query.trim().isEmpty()) {
            adapter.submit(fullRows);
            return;
        }
        String q = query.trim().toLowerCase();
        List<FuelEntryDisplay> filtered = new ArrayList<>();
        for (FuelEntryDisplay row : fullRows) {
            FuelEntry e = row.getEntry();
            String date = FormatUtils.formatDate(e.getDateMillis()).toLowerCase();
            String litres = String.format(java.util.Locale.getDefault(), "%.2f", e.getLitres());
            String cost = FormatUtils.formatCurrency(e.getTotalCost()).toLowerCase();
            String odo = FormatUtils.formatOdometer(e.getOdometerKm()).toLowerCase();
            if (date.contains(q) || litres.contains(q) || cost.contains(q) || odo.contains(q)) {
                filtered.add(row);
            }
        }
        adapter.submit(filtered);
    }

    @Override
    public void onEdit(FuelEntryDisplay row) {
        Intent i = new Intent(requireContext(), AddEditFuelEntryActivity.class);
        i.putExtra(AddEditFuelEntryActivity.EXTRA_ENTRY_ID, row.getEntry().getId());
        editLauncher.launch(i);
    }

    @Override
    public void onDelete(FuelEntryDisplay row) {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.dialog_delete_title)
                .setMessage(R.string.dialog_delete_message)
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.action_delete, (d, w) ->
                        repository.delete(row.getEntry(), null))
                .show();
    }

    private void exportCsv() {
        repository.getAllByDateDesc(list -> {
            try {
                File file = ExportUtils.exportCsv(requireContext(), list);
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/csv");
                share.putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(
                        requireContext(),
                        requireContext().getPackageName() + ".fileprovider",
                        file));
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(share, getString(R.string.share_csv_title)));
            } catch (Exception e) {
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(requireContext(), R.string.error_export, Toast.LENGTH_LONG).show());
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
