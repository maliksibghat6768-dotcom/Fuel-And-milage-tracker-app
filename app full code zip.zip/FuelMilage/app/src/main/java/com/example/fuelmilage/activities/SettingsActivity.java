package com.example.fuelmilage.activities;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fuelmilage.R;
import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.databinding.ActivitySettingsBinding;
import com.example.fuelmilage.firebase.FirebaseAuthHelper;
import com.example.fuelmilage.utils.AppPreferences;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

/**
 * Maintenance, theme, notifications, and account settings.
 */
public class SettingsActivity extends AppCompatActivity {

    private ActivitySettingsBinding binding;
    private AppPreferences prefs;
    private FuelRepository repository;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.toolbar.setNavigationOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());

        prefs = new AppPreferences(this);
        repository = FuelRepository.get(this);

        binding.inputInterval.setText(String.valueOf(prefs.getMaintenanceIntervalKm()));
        binding.inputTitle.setText(prefs.getMaintenanceTitle());
        binding.inputRefillDays.setText(String.valueOf(prefs.getRefillIntervalDays()));

        binding.switchLowMileage.setChecked(prefs.isNotifyLowMileage());
        binding.switchRefill.setChecked(prefs.isNotifyRefill());
        binding.switchMaintenance.setChecked(prefs.isNotifyMaintenance());
        binding.switchHighSpend.setChecked(prefs.isNotifyHighSpend());

        binding.buttonTheme.setOnClickListener(v -> showThemePicker());
        binding.buttonSave.setOnClickListener(v -> savePrefs());
        binding.buttonMarkService.setOnClickListener(v -> markServiceAtLatestOdometer());
        binding.buttonLogout.setOnClickListener(v -> {
            new FirebaseAuthHelper(this).logout();
            prefs.setSkipLogin(false);
            Toast.makeText(this, R.string.auth_logged_out, Toast.LENGTH_SHORT).show();
            finish();
        });
        binding.buttonLogout.setVisibility(
                new FirebaseAuthHelper(this).isLoggedIn()
                        ? android.view.View.VISIBLE : android.view.View.GONE);
    }

    private void showThemePicker() {
        String[] labels = {
                getString(R.string.theme_system),
                getString(R.string.theme_light),
                getString(R.string.theme_dark)
        };
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.settings_theme)
                .setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, labels),
                        (d, which) -> prefs.setThemeMode(which))
                .show();
    }

    private void savePrefs() {
        String intervalRaw = binding.inputInterval.getText() != null
                ? binding.inputInterval.getText().toString().trim()
                : "";
        try {
            int km = Integer.parseInt(intervalRaw);
            prefs.setMaintenanceIntervalKm(km);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.error_invalid_interval, Toast.LENGTH_LONG).show();
            return;
        }
        String title = binding.inputTitle.getText() != null
                ? binding.inputTitle.getText().toString().trim() : "";
        prefs.setMaintenanceTitle(title.isEmpty() ? getString(R.string.default_service_title) : title);

        try {
            int days = Integer.parseInt(binding.inputRefillDays.getText().toString().trim());
            prefs.setRefillIntervalDays(days);
        } catch (Exception e) {
            Toast.makeText(this, R.string.error_invalid_interval, Toast.LENGTH_LONG).show();
            return;
        }

        prefs.setNotifyLowMileage(binding.switchLowMileage.isChecked());
        prefs.setNotifyRefill(binding.switchRefill.isChecked());
        prefs.setNotifyMaintenance(binding.switchMaintenance.isChecked());
        prefs.setNotifyHighSpend(binding.switchHighSpend.isChecked());

        Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void markServiceAtLatestOdometer() {
        repository.getMaxOdometer(max -> {
            if (max == null || max <= 0) {
                runOnUiThread(() -> Toast.makeText(this, R.string.error_no_odometer_data, Toast.LENGTH_LONG).show());
                return;
            }
            prefs.setMaintenanceBaseOdometerKm(max);
            runOnUiThread(() -> Toast.makeText(this, R.string.msg_service_recorded, Toast.LENGTH_LONG).show());
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
