package com.example.fuelmilage.utils;

/**
 * Computes eco-driving score from behavior counters.
 */
public final class DrivingScoreCalculator {

    private DrivingScoreCalculator() {
    }

    public static int computeEcoScore(int harshBraking, int rapidAccel, int highSpeed) {
        int score = 100;
        score -= harshBraking * 8;
        score -= rapidAccel * 6;
        score -= highSpeed * 10;
        return Math.max(10, Math.min(100, score));
    }
}
