package com.example.fuelmilage.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fuelmilage.databinding.ItemVehicleBinding;
import com.example.fuelmilage.models.Vehicle;

import java.util.ArrayList;
import java.util.List;

public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.Holder> {

    public interface Listener {
        void onSelect(Vehicle vehicle);

        void onEdit(Vehicle vehicle);
    }

    private final Listener listener;
    private List<Vehicle> items = new ArrayList<>();

    public VehicleAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<Vehicle> vehicles) {
        items = vehicles != null ? vehicles : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(ItemVehicleBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.bind(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class Holder extends RecyclerView.ViewHolder {
        private final ItemVehicleBinding binding;

        Holder(ItemVehicleBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(Vehicle vehicle) {
            binding.textName.setText(vehicle.getName());
            binding.textDetails.setText(vehicle.getModel() + " • " + vehicle.getFuelType());
            binding.chipActive.setVisibility(vehicle.isActive() ? View.VISIBLE : View.GONE);
            binding.getRoot().setOnClickListener(v -> listener.onSelect(vehicle));
            binding.buttonEdit.setOnClickListener(v -> listener.onEdit(vehicle));
        }
    }
}
