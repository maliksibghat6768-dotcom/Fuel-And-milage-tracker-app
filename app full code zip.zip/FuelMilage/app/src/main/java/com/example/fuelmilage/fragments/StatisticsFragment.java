package com.example.fuelmilage.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;

import com.example.fuelmilage.R;
import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.databinding.FragmentStatisticsBinding;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.utils.FormatUtils;
import com.example.fuelmilage.utils.MileageCalculator;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/**
 * Charts for monthly spend and mileage trend plus headline stats.
 */
public class StatisticsFragment extends Fragment {

    private FragmentStatisticsBinding binding;
    private FuelRepository repository;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentStatisticsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        repository = FuelRepository.get(requireContext());
        configureLineChart(binding.chartMileageTrend);
        configureLineChart(binding.chartEfficiency);
        configureBarChart(binding.chartMonthlySpend);

        binding.chartMileageTrend.setNestedScrollingEnabled(false);
        binding.chartEfficiency.setNestedScrollingEnabled(false);
        binding.chartMonthlySpend.setNestedScrollingEnabled(false);

        LiveData<List<FuelEntry>> live = repository.observeAllByDateDesc();
        live.observe(getViewLifecycleOwner(), this::render);
    }

    private void configureLineChart(com.github.mikephil.charting.charts.LineChart chart) {
        chart.getDescription().setEnabled(false);
        chart.setNoDataText(getString(R.string.chart_no_data));
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(true);
    }

    private void configureBarChart(com.github.mikephil.charting.charts.BarChart chart) {
        chart.getDescription().setEnabled(false);
        chart.setNoDataText(getString(R.string.chart_no_data));
        chart.setTouchEnabled(true);
        chart.setDragEnabled(true);
        chart.setScaleEnabled(true);
        chart.setPinchZoom(false);
    }

    private void render(List<FuelEntry> raw) {
        if (raw == null || raw.isEmpty()) {
            binding.textStatsSummary.setText(R.string.stats_empty);
            binding.chartMileageTrend.clear();
            binding.chartEfficiency.clear();
            binding.chartMonthlySpend.clear();
            return;
        }

        List<FuelEntryDisplay> rows = MileageCalculator.buildDisplayList(raw);
        double avg = MileageCalculator.averageMileage(rows);
        double totalCost = MileageCalculator.totalCost(raw);
        binding.textStatsSummary.setText(getString(
                R.string.stats_summary,
                FormatUtils.formatMileage(avg),
                FormatUtils.formatCurrency(totalCost)));

        bindMileageTrend(rows);
        bindEfficiencyComparison(rows);
        bindMonthlySpend(raw);
    }

    private void bindEfficiencyComparison(List<FuelEntryDisplay> rows) {
        bindMileageToChart(binding.chartEfficiency, rows, R.color.chart_bar);
    }

    private void bindMileageToChart(com.github.mikephil.charting.charts.LineChart chart,
                                    List<FuelEntryDisplay> rows, int colorRes) {
        List<FuelEntryDisplay> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparingLong(a -> a.getEntry().getDateMillis()));

        List<Entry> points = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int idx = 0;
        for (FuelEntryDisplay d : sorted) {
            if (d.getMileageKmPerLitre() > 0) {
                points.add(new Entry(idx, (float) d.getMileageKmPerLitre()));
                labels.add(FormatUtils.formatDate(d.getEntry().getDateMillis()));
                idx++;
            }
        }
        if (points.isEmpty()) {
            chart.clear();
            chart.invalidate();
            return;
        }
        int color = ContextCompat.getColor(requireContext(), colorRes);
        LineDataSet set = new LineDataSet(points, getString(R.string.chart_label_efficiency));
        set.setColor(color);
        set.setCircleColor(color);
        set.setDrawValues(false);
        chart.setData(new LineData(set));
        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setValueFormatter(new IndexAxisValueFormatter(labels));
        chart.getAxisRight().setEnabled(false);
        chart.invalidate();
    }

    private void bindMileageTrend(List<FuelEntryDisplay> rows) {
        List<FuelEntryDisplay> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparingLong(a -> a.getEntry().getDateMillis()));

        List<Entry> points = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int idx = 0;
        for (FuelEntryDisplay d : sorted) {
            if (d.getMileageKmPerLitre() > 0) {
                points.add(new Entry(idx, (float) d.getMileageKmPerLitre()));
                labels.add(FormatUtils.formatDate(d.getEntry().getDateMillis()));
                idx++;
            }
        }

        if (points.isEmpty()) {
            binding.chartMileageTrend.clear();
            binding.chartMileageTrend.invalidate();
            return;
        }

        int lineColor = ContextCompat.getColor(requireContext(), R.color.chart_line);
        LineDataSet set = new LineDataSet(points, getString(R.string.chart_label_mileage));
        set.setColor(lineColor);
        set.setCircleColor(lineColor);
        set.setLineWidth(2f);
        set.setDrawValues(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);

        LineData data = new LineData(set);
        binding.chartMileageTrend.setData(data);
        XAxis x = binding.chartMileageTrend.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setGranularity(1f);
        x.setValueFormatter(new IndexAxisValueFormatter(labels));
        x.setLabelRotationAngle(-30f);
        binding.chartMileageTrend.getAxisRight().setEnabled(false);
        binding.chartMileageTrend.getLegend().setEnabled(true);
        binding.chartMileageTrend.invalidate();
    }

    private void bindMonthlySpend(List<FuelEntry> raw) {
        Map<Integer, Double> totals = new TreeMap<>();
        Calendar c = Calendar.getInstance();
        for (FuelEntry e : raw) {
            c.setTimeInMillis(e.getDateMillis());
            int ym = c.get(Calendar.YEAR) * 100 + c.get(Calendar.MONTH);
            totals.put(ym, totals.getOrDefault(ym, 0d) + e.getTotalCost());
        }

        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int i = 0;
        SimpleDateFormat fmt = new SimpleDateFormat("MMM yy", Locale.getDefault());
        for (Map.Entry<Integer, Double> bucket : totals.entrySet()) {
            int ym = bucket.getKey();
            int year = ym / 100;
            int month = ym % 100;
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.YEAR, year);
            cal.set(Calendar.MONTH, month);
            cal.set(Calendar.DAY_OF_MONTH, 1);
            labels.add(fmt.format(cal.getTime()));
            entries.add(new BarEntry(i++, bucket.getValue().floatValue()));
        }

        if (entries.isEmpty()) {
            binding.chartMonthlySpend.clear();
            binding.chartMonthlySpend.invalidate();
            return;
        }

        int barColor = ContextCompat.getColor(requireContext(), R.color.chart_bar);
        BarDataSet set = new BarDataSet(entries, getString(R.string.chart_label_monthly_spend));
        set.setColor(barColor);
        set.setValueTextSize(10f);
        BarData data = new BarData(set);
        data.setBarWidth(0.45f);
        binding.chartMonthlySpend.setData(data);
        XAxis x = binding.chartMonthlySpend.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setGranularity(1f);
        x.setValueFormatter(new IndexAxisValueFormatter(labels));
        x.setLabelRotationAngle(-25f);
        binding.chartMonthlySpend.getAxisRight().setEnabled(false);
        binding.chartMonthlySpend.getAxisLeft().setTextColor(
                ContextCompat.getColor(requireContext(), R.color.chart_axis));
        binding.chartMonthlySpend.setFitBars(true);
        binding.chartMonthlySpend.invalidate();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
