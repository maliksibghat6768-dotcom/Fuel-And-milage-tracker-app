package com.example.fuelmilage.utils;

import com.example.fuelmilage.models.FuelEntry;

import java.util.Calendar;
import java.util.List;

/**
 * Predicts monthly fuel usage and spend from historical fill-ups.
 */
public final class MileagePredictor {

    public static class Prediction {
        public final double predictedLitres;
        public final double predictedCost;
        public final String summary;

        public Prediction(double predictedLitres, double predictedCost, String summary) {
            this.predictedLitres = predictedLitres;
            this.predictedCost = predictedCost;
            this.summary = summary;
        }
    }

    private MileagePredictor() {
    }

    public static Prediction predictNextMonth(List<FuelEntry> entries) {
        if (entries == null || entries.isEmpty()) {
            return new Prediction(0, 0, "Add fuel entries to see monthly predictions.");
        }

        Calendar c = Calendar.getInstance();
        c.add(Calendar.MONTH, -3);
        long since = c.getTimeInMillis();

        double litres = 0;
        double cost = 0;
        int count = 0;
        for (FuelEntry e : entries) {
            if (e.getDateMillis() >= since) {
                litres += e.getLitres();
                cost += e.getTotalCost();
                count++;
            }
        }
        if (count == 0) {
            for (FuelEntry e : entries) {
                litres += e.getLitres();
                cost += e.getTotalCost();
            }
            count = entries.size();
        }

        double months = Math.max(1, count / 2.0);
        double predLitres = litres / months;
        double predCost = cost / months;
        String summary = String.format(
                "Based on recent data: ~%s fuel and ~%s spend next month.",
                FormatUtils.formatLitres(predLitres),
                FormatUtils.formatCurrency(predCost));
        return new Prediction(predLitres, predCost, summary);
    }
}
