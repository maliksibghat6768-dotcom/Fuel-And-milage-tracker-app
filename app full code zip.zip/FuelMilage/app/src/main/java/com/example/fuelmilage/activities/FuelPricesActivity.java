package com.example.fuelmilage.activities;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.fuelmilage.databinding.ActivityFuelPricesBinding;
import com.example.fuelmilage.models.FuelPriceInfo;
import com.example.fuelmilage.utils.FormatUtils;
import com.example.fuelmilage.utils.FuelPriceService;

/**
 * Live fuel prices screen (mock API asset with optional remote URL).
 */
public class FuelPricesActivity extends AppCompatActivity {

    private ActivityFuelPricesBinding binding;
    private final FuelPriceService priceService = new FuelPriceService();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityFuelPricesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        binding.swipeRefresh.setOnRefreshListener(this::loadPrices);
        loadPrices();
    }

    private void loadPrices() {
        binding.progress.setVisibility(View.VISIBLE);
        binding.swipeRefresh.setRefreshing(true);
        priceService.fetch(this, new FuelPriceService.Callback() {
            @Override
            public void onResult(FuelPriceInfo info) {
                runOnUiThread(() -> showPrices(info));
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    binding.progress.setVisibility(View.GONE);
                    binding.swipeRefresh.setRefreshing(false);
                    binding.textError.setVisibility(View.VISIBLE);
                    binding.textError.setText(message);
                });
            }
        });
    }

    private void showPrices(FuelPriceInfo info) {
        binding.progress.setVisibility(View.GONE);
        binding.swipeRefresh.setRefreshing(false);
        binding.textError.setVisibility(View.GONE);
        binding.textPetrol.setText(FormatUtils.formatCurrency(info.getPetrolPrice()));
        binding.textDiesel.setText(FormatUtils.formatCurrency(info.getDieselPrice()));
        long updated = info.getUpdatedAtMillis() > 0
                ? info.getUpdatedAtMillis() : System.currentTimeMillis();
        binding.textUpdated.setText(getString(com.example.fuelmilage.R.string.fuel_prices_updated,
                FormatUtils.formatDateTime(updated), info.getRegion()));
    }
}
