package com.example.fuelmilage.services;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/**
 * Schedules sync and smart notification workers.
 */
public final class WorkScheduler {

    private static final String SYNC_WORK = "cloud_sync_work";
    private static final String ALERT_WORK = "smart_alert_work";

    private WorkScheduler() {
    }

    public static void scheduleAll(Context context) {
        Constraints network = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        PeriodicWorkRequest sync = new PeriodicWorkRequest.Builder(SyncWorker.class, 6, TimeUnit.HOURS)
                .setConstraints(network)
                .build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                SYNC_WORK,
                ExistingPeriodicWorkPolicy.KEEP,
                sync);

        PeriodicWorkRequest alerts = new PeriodicWorkRequest.Builder(SmartAlertWorker.class, 12, TimeUnit.HOURS)
                .build();
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                ALERT_WORK,
                ExistingPeriodicWorkPolicy.KEEP,
                alerts);
    }
}
