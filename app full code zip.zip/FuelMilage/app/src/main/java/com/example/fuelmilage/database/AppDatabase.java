package com.example.fuelmilage.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.fuelmilage.models.DrivingSession;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.MaintenanceItem;
import com.example.fuelmilage.models.Trip;
import com.example.fuelmilage.models.Vehicle;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Application Room database. Single process singleton.
 */
@Database(
        entities = {
                FuelEntry.class,
                Vehicle.class,
                Trip.class,
                MaintenanceItem.class,
                DrivingSession.class
        },
        version = 2,
        exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DB_NAME = "fuel_mileage.db";
    private static volatile AppDatabase instance;
    private static final ExecutorService SEED_EXECUTOR = Executors.newSingleThreadExecutor();

    public abstract FuelEntryDao fuelEntryDao();

    public abstract VehicleDao vehicleDao();

    public abstract TripDao tripDao();

    public abstract MaintenanceDao maintenanceDao();

    public abstract DrivingSessionDao drivingSessionDao();

    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            synchronized (AppDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(
                                    context.getApplicationContext(),
                                    AppDatabase.class,
                                    DB_NAME)
                            .fallbackToDestructiveMigration()
                            .build();
                    // Seed defaults off the main thread to avoid Room main-thread exceptions at app start.
                    AppDatabase db = instance;
                    SEED_EXECUTOR.execute(() -> DatabaseSeeder.ensureDefaults(db));
                }
            }
        }
        return instance;
    }
}
