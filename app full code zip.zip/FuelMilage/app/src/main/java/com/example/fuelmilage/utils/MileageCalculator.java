package com.example.fuelmilage.utils;

import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Computes per-segment distance and mileage from ordered odometer readings.
 */
public final class MileageCalculator {

    private MileageCalculator() {
    }

    /**
     * Builds display rows sorted by date descending (newest first) with mileage for each segment
     * based on ascending odometer order.
     */
    public static List<FuelEntryDisplay> buildDisplayList(List<FuelEntry> raw) {
        if (raw == null || raw.isEmpty()) {
            return Collections.emptyList();
        }
        List<FuelEntry> byOdo = new ArrayList<>(raw);
        byOdo.sort(Comparator.comparingDouble(FuelEntry::getOdometerKm));

        List<FuelEntryDisplay> rows = new ArrayList<>();
        FuelEntry previous = null;
        for (FuelEntry current : byOdo) {
            double distance = 0;
            if (previous != null) {
                distance = Math.max(0, current.getOdometerKm() - previous.getOdometerKm());
            }
            double mileage = 0;
            if (distance > 0 && current.getLitres() > 0) {
                mileage = distance / current.getLitres();
            }
            rows.add(new FuelEntryDisplay(current, distance, mileage));
            previous = current;
        }

        // Map back to date-desc order for UI
        rows.sort((a, b) -> Long.compare(b.getEntry().getDateMillis(), a.getEntry().getDateMillis()));
        return rows;
    }

    /** Average of positive segment mileages (km/L). */
    public static double averageMileage(List<FuelEntryDisplay> rows) {
        double sum = 0;
        int n = 0;
        for (FuelEntryDisplay r : rows) {
            if (r.getMileageKmPerLitre() > 0) {
                sum += r.getMileageKmPerLitre();
                n++;
            }
        }
        return n == 0 ? 0 : sum / n;
    }

    /** Total fuel cost across all entries. */
    public static double totalCost(List<FuelEntry> raw) {
        double t = 0;
        if (raw == null) {
            return 0;
        }
        for (FuelEntry e : raw) {
            t += e.getTotalCost();
        }
        return t;
    }

    /** Total litres purchased. */
    public static double totalLitres(List<FuelEntry> raw) {
        double t = 0;
        if (raw == null) {
            return 0;
        }
        for (FuelEntry e : raw) {
            t += e.getLitres();
        }
        return t;
    }

    /** Odometer span from min to max reading (approximate total distance while tracking). */
    public static double totalDistanceSpan(List<FuelEntry> raw) {
        if (raw == null || raw.size() < 2) {
            return 0;
        }
        double min = Double.MAX_VALUE;
        double max = Double.MIN_VALUE;
        for (FuelEntry e : raw) {
            min = Math.min(min, e.getOdometerKm());
            max = Math.max(max, e.getOdometerKm());
        }
        return Math.max(0, max - min);
    }

    /**
     * Returns true if recent average mileage dropped significantly vs earlier trips.
     * Uses up to last 3 vs previous 3 positive segment mileages.
     */
    public static boolean hasMileageDropWarning(List<FuelEntryDisplay> rows) {
        List<Double> m = new ArrayList<>();
        List<FuelEntry> byOdo = new ArrayList<>();
        for (FuelEntryDisplay d : rows) {
            byOdo.add(d.getEntry());
        }
        byOdo.sort(Comparator.comparingDouble(FuelEntry::getOdometerKm));
        FuelEntry prev = null;
        for (FuelEntry cur : byOdo) {
            if (prev != null) {
                double dist = Math.max(0, cur.getOdometerKm() - prev.getOdometerKm());
                if (dist > 0 && cur.getLitres() > 0) {
                    m.add(dist / cur.getLitres());
                }
            }
            prev = cur;
        }
        if (m.size() < 4) {
            return false;
        }
        int n = m.size();
        double recent = avgLast(m, Math.min(3, n / 2));
        double older = avgBeforeLast(m, Math.min(3, n / 2));
        if (older <= 0 || recent <= 0) {
            return false;
        }
        double drop = (older - recent) / older;
        return drop >= 0.12;
    }

    private static double avgLast(List<Double> values, int count) {
        int start = Math.max(0, values.size() - count);
        double s = 0;
        for (int i = start; i < values.size(); i++) {
            s += values.get(i);
        }
        return s / (values.size() - start);
    }

    private static double avgBeforeLast(List<Double> values, int count) {
        int end = values.size() - count;
        if (end <= 0) {
            return 0;
        }
        int start = Math.max(0, end - count);
        double s = 0;
        int n = 0;
        for (int i = start; i < end; i++) {
            s += values.get(i);
            n++;
        }
        return n == 0 ? 0 : s / n;
    }
}
