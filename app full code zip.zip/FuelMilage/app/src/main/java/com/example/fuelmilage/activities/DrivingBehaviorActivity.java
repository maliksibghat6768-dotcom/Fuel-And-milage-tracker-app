package com.example.fuelmilage.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fuelmilage.R;
import com.example.fuelmilage.databinding.ActivityDrivingBehaviorBinding;
import com.example.fuelmilage.databinding.DialogDrivingBinding;
import com.example.fuelmilage.models.DrivingSession;
import com.example.fuelmilage.repository.AppRepository;
import com.example.fuelmilage.utils.DrivingScoreCalculator;

import java.util.List;

/**
 * Log driving behavior events and compute eco-driving score.
 */
public class DrivingBehaviorActivity extends AppCompatActivity {

    private ActivityDrivingBehaviorBinding binding;
    private AppRepository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityDrivingBehaviorBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        repository = AppRepository.get(this);
        binding.buttonLog.setOnClickListener(v -> showLogDialog());
        refreshSummary();
    }

    private void refreshSummary() {
        repository.getRecentDrivingSessions(sessions -> runOnUiThread(() -> {
            if (sessions == null || sessions.isEmpty()) {
                binding.textEcoScore.setText("—");
                binding.textSummary.setText(R.string.driving_empty);
                return;
            }
            int totalScore = 0;
            for (DrivingSession s : sessions) {
                totalScore += s.getEcoScore();
            }
            int avg = totalScore / sessions.size();
            binding.textEcoScore.setText(getString(R.string.driving_eco_score, avg));
            DrivingSession latest = sessions.get(0);
            binding.textSummary.setText(getString(R.string.driving_latest,
                    latest.getHarshBrakingCount(),
                    latest.getRapidAccelerationCount(),
                    latest.getHighSpeedAlerts()));
        }));
    }

    private void showLogDialog() {
        DialogDrivingBinding d = DialogDrivingBinding.inflate(LayoutInflater.from(this));
        d.seekHarsh.setOnSeekBarChangeListener(emptyListener(d.textHarshVal));
        d.seekAccel.setOnSeekBarChangeListener(emptyListener(d.textAccelVal));
        d.seekSpeed.setOnSeekBarChangeListener(emptyListener(d.textSpeedVal));
        updateSeekLabel(d.seekHarsh, d.textHarshVal);
        updateSeekLabel(d.seekAccel, d.textAccelVal);
        updateSeekLabel(d.seekSpeed, d.textSpeedVal);

        new AlertDialog.Builder(this)
                .setTitle(R.string.driving_log_session)
                .setView(d.getRoot())
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.action_save, (dialog, which) -> {
                    int harsh = d.seekHarsh.getProgress();
                    int accel = d.seekAccel.getProgress();
                    int speed = d.seekSpeed.getProgress();
                    int score = DrivingScoreCalculator.computeEcoScore(harsh, accel, speed);
                    DrivingSession session = new DrivingSession(
                            repository.getActiveVehicleId(),
                            System.currentTimeMillis(),
                            harsh, accel, speed, score,
                            d.inputNotes.getEditText() != null
                                    ? String.valueOf(d.inputNotes.getEditText().getText()) : "");
                    repository.insertDrivingSession(session, id -> {
                        Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show();
                        refreshSummary();
                    });
                })
                .show();
    }

    private static SeekBar.OnSeekBarChangeListener emptyListener(android.widget.TextView label) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                label.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        };
    }

    private static void updateSeekLabel(SeekBar seekBar, android.widget.TextView label) {
        label.setText(String.valueOf(seekBar.getProgress()));
    }
}
