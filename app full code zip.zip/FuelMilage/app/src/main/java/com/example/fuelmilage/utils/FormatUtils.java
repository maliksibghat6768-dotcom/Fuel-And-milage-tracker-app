package com.example.fuelmilage.utils;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Currency;
import java.util.Date;
import java.util.Locale;

/**
 * Locale-aware formatting for currency, distance, and fuel volume.
 */
public final class FormatUtils {

    private FormatUtils() {
    }

    public static String formatDate(long millis) {
        return DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.getDefault())
                .format(new Date(millis));
    }

    public static String formatDateTime(long millis) {
        return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.getDefault())
                .format(new Date(millis));
    }

    public static String formatCurrency(double amount) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.getDefault());
        try {
            nf.setCurrency(Currency.getInstance(Locale.getDefault()));
        } catch (Exception ignored) {
            // Fallback if locale has no currency
        }
        return nf.format(amount);
    }

    public static String formatLitres(double litres) {
        return String.format(Locale.getDefault(), "%.2f L", litres);
    }

    public static String formatKm(double km) {
        return String.format(Locale.getDefault(), "%.1f km", km);
    }

    public static String formatMileage(double kmPerLitre) {
        if (kmPerLitre <= 0) {
            return "—";
        }
        return String.format(Locale.getDefault(), "%.2f km/L", kmPerLitre);
    }

    public static String formatOdometer(double km) {
        return String.format(Locale.getDefault(), "%.0f km", km);
    }
}
