package com.example.fuelmilage.activities;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.LiveData;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.fuelmilage.R;
import com.example.fuelmilage.adapters.VehicleAdapter;
import com.example.fuelmilage.databinding.ActivityVehiclesBinding;
import com.example.fuelmilage.databinding.DialogVehicleBinding;
import com.example.fuelmilage.models.Vehicle;
import com.example.fuelmilage.repository.AppRepository;

import java.util.List;

/**
 * Multi-vehicle management: add, edit, switch active vehicle.
 */
public class VehiclesActivity extends AppCompatActivity implements VehicleAdapter.Listener {

    private ActivityVehiclesBinding binding;
    private AppRepository repository;
    private VehicleAdapter adapter;
    private Vehicle editing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityVehiclesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        binding.toolbar.setNavigationOnClickListener(v -> finish());
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        repository = AppRepository.get(this);
        adapter = new VehicleAdapter(this);
        binding.recycler.setLayoutManager(new LinearLayoutManager(this));
        binding.recycler.setAdapter(adapter);

        binding.fabAdd.setOnClickListener(v -> showVehicleDialog(null));

        LiveData<List<Vehicle>> live = repository.observeVehicles();
        live.observe(this, adapter::submit);
    }

    @Override
    public void onSelect(Vehicle vehicle) {
        repository.setActiveVehicle(vehicle.getId(), () ->
                Toast.makeText(this, getString(R.string.vehicle_switched, vehicle.getName()), Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onEdit(Vehicle vehicle) {
        showVehicleDialog(vehicle);
    }

    private void showVehicleDialog(Vehicle vehicle) {
        editing = vehicle;
        DialogVehicleBinding dialogBinding = DialogVehicleBinding.inflate(LayoutInflater.from(this));
        if (vehicle != null) {
            dialogBinding.inputName.getEditText().setText(vehicle.getName());
            dialogBinding.inputModel.getEditText().setText(vehicle.getModel());
            dialogBinding.inputFuelType.getEditText().setText(vehicle.getFuelType());
        }
        new AlertDialog.Builder(this)
                .setTitle(vehicle == null ? R.string.vehicle_add : R.string.vehicle_edit)
                .setView(dialogBinding.getRoot())
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(R.string.action_save, (d, w) -> saveVehicle(dialogBinding))
                .show();
    }

    private void saveVehicle(DialogVehicleBinding dialogBinding) {
        String name = text(dialogBinding.inputName);
        String model = text(dialogBinding.inputModel);
        String fuel = text(dialogBinding.inputFuelType);
        if (name.isEmpty()) {
            Toast.makeText(this, R.string.vehicle_name_required, Toast.LENGTH_SHORT).show();
            return;
        }
        if (editing == null) {
            Vehicle v = new Vehicle(name, model.isEmpty() ? "—" : model, fuel.isEmpty() ? "Petrol" : fuel);
            repository.insertVehicle(v, id -> Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show());
        } else {
            editing.setName(name);
            editing.setModel(model);
            editing.setFuelType(fuel);
            repository.updateVehicle(editing, () ->
                    Toast.makeText(this, R.string.msg_saved, Toast.LENGTH_SHORT).show());
        }
    }

    private static String text(com.google.android.material.textfield.TextInputLayout layout) {
        return layout.getEditText() != null && layout.getEditText().getText() != null
                ? layout.getEditText().getText().toString().trim() : "";
    }
}
