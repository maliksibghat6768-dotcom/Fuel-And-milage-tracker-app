package com.example.fuelmilage.repository;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.LiveData;

import com.example.fuelmilage.database.AppDatabase;
import com.example.fuelmilage.database.DrivingSessionDao;
import com.example.fuelmilage.database.FuelEntryDao;
import com.example.fuelmilage.database.MaintenanceDao;
import com.example.fuelmilage.database.TripDao;
import com.example.fuelmilage.database.VehicleDao;
import com.example.fuelmilage.models.DrivingSession;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.MaintenanceItem;
import com.example.fuelmilage.models.Trip;
import com.example.fuelmilage.models.Vehicle;
import com.example.fuelmilage.utils.AppPreferences;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Central repository for vehicles, fuel entries, trips, maintenance, and driving sessions.
 */
public class AppRepository {

    private static volatile AppRepository instance;
    private final FuelEntryDao fuelDao;
    private final VehicleDao vehicleDao;
    private final TripDao tripDao;
    private final MaintenanceDao maintenanceDao;
    private final DrivingSessionDao drivingDao;
    private final AppPreferences prefs;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private AppRepository(Context appContext) {
        AppDatabase db = AppDatabase.getInstance(appContext);
        fuelDao = db.fuelEntryDao();
        vehicleDao = db.vehicleDao();
        tripDao = db.tripDao();
        maintenanceDao = db.maintenanceDao();
        drivingDao = db.drivingSessionDao();
        prefs = new AppPreferences(appContext);
    }

    public static AppRepository get(Context context) {
        if (instance == null) {
            synchronized (AppRepository.class) {
                if (instance == null) {
                    instance = new AppRepository(context.getApplicationContext());
                }
            }
        }
        return instance;
    }

    public long getActiveVehicleId() {
        return prefs.getActiveVehicleId();
    }

    public LiveData<List<FuelEntry>> observeFuelForActiveVehicle() {
        return fuelDao.observeByVehicle(getActiveVehicleId());
    }

    public LiveData<List<Vehicle>> observeVehicles() {
        return vehicleDao.observeAll();
    }

    public LiveData<List<Trip>> observeTripsForActiveVehicle() {
        return tripDao.observeByVehicle(getActiveVehicleId());
    }

    public LiveData<List<MaintenanceItem>> observeMaintenanceForActiveVehicle() {
        return maintenanceDao.observeEnabled(getActiveVehicleId());
    }

    public LiveData<List<DrivingSession>> observeDrivingForActiveVehicle() {
        return drivingDao.observeByVehicle(getActiveVehicleId());
    }

    public void io(Runnable task) {
        io.execute(task);
    }

    public void onMain(Runnable task) {
        main.post(task);
    }

    public void getFuelForActiveVehicle(Callback<List<FuelEntry>> callback) {
        io.execute(() -> {
            List<FuelEntry> list = fuelDao.getByVehicle(getActiveVehicleId());
            main.post(() -> callback.onResult(list));
        });
    }

    public void getAllFuel(Callback<List<FuelEntry>> callback) {
        io.execute(() -> {
            List<FuelEntry> list = fuelDao.getAllByDateDesc();
            main.post(() -> callback.onResult(list));
        });
    }

    public void getById(long id, Callback<FuelEntry> callback) {
        io.execute(() -> main.post(() -> callback.onResult(fuelDao.getById(id))));
    }

    public void getMaxOdometerForActiveVehicle(Callback<Double> callback) {
        io.execute(() -> main.post(() ->
                callback.onResult(fuelDao.getMaxOdometerForVehicle(getActiveVehicleId()))));
    }

    public void getMaxOdometerExcluding(long excludeId, Callback<Double> callback) {
        io.execute(() -> main.post(() -> callback.onResult(
                fuelDao.getMaxOdometerExcludingForVehicle(getActiveVehicleId(), excludeId))));
    }

    public void insertFuel(FuelEntry entry, Callback<Long> callback) {
        entry.setVehicleId(getActiveVehicleId());
        entry.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            long id = fuelDao.insert(entry);
            main.post(() -> callback.onResult(id));
        });
    }

    public void updateFuel(FuelEntry entry, Runnable done) {
        entry.setVehicleId(getActiveVehicleId());
        entry.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            fuelDao.update(entry);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void deleteFuel(FuelEntry entry, Runnable done) {
        io.execute(() -> {
            fuelDao.delete(entry);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void getVehicles(Callback<List<Vehicle>> callback) {
        io.execute(() -> main.post(() -> callback.onResult(vehicleDao.getAll())));
    }

    public void insertVehicle(Vehicle vehicle, Callback<Long> callback) {
        vehicle.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            long id = vehicleDao.insert(vehicle);
            main.post(() -> callback.onResult(id));
        });
    }

    public void updateVehicle(Vehicle vehicle, Runnable done) {
        vehicle.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            vehicleDao.update(vehicle);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void setActiveVehicle(long vehicleId, Runnable done) {
        io.execute(() -> {
            vehicleDao.clearActive();
            Vehicle v = vehicleDao.getById(vehicleId);
            if (v != null) {
                v.setActive(true);
                vehicleDao.update(v);
                prefs.setActiveVehicleId(vehicleId);
            }
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void insertTrip(Trip trip, Callback<Long> callback) {
        trip.setVehicleId(getActiveVehicleId());
        trip.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            long id = tripDao.insert(trip);
            main.post(() -> callback.onResult(id));
        });
    }

    public void deleteTrip(Trip trip, Runnable done) {
        io.execute(() -> {
            tripDao.delete(trip);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void insertMaintenance(MaintenanceItem item, Callback<Long> callback) {
        item.setVehicleId(getActiveVehicleId());
        item.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            long id = maintenanceDao.insert(item);
            main.post(() -> callback.onResult(id));
        });
    }

    public void updateMaintenance(MaintenanceItem item, Runnable done) {
        item.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            maintenanceDao.update(item);
            if (done != null) {
                main.post(done);
            }
        });
    }

    public void insertDrivingSession(DrivingSession session, Callback<Long> callback) {
        session.setVehicleId(getActiveVehicleId());
        session.setUpdatedAtMillis(System.currentTimeMillis());
        io.execute(() -> {
            long id = drivingDao.insert(session);
            main.post(() -> callback.onResult(id));
        });
    }

    public void getRecentDrivingSessions(Callback<List<DrivingSession>> callback) {
        io.execute(() -> main.post(() ->
                callback.onResult(drivingDao.getRecent(getActiveVehicleId()))));
    }

    public void getTripsForActiveVehicle(Callback<List<Trip>> callback) {
        io.execute(() -> main.post(() ->
                callback.onResult(tripDao.getByVehicle(getActiveVehicleId()))));
    }

    public FuelEntryDao fuelDao() {
        return fuelDao;
    }

    public MaintenanceDao maintenanceDao() {
        return maintenanceDao;
    }

    public interface Callback<T> {
        void onResult(T value);
    }
}
