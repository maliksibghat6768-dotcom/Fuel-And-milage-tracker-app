package com.example.fuelmilage.models;

/** Nearby petrol station marker for maps. */
public class PetrolPump {

    private final String name;
    private final double latitude;
    private final double longitude;
    private final double distanceKm;

    public PetrolPump(String name, double latitude, double longitude, double distanceKm) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.distanceKm = distanceKm;
    }

    public String getName() {
        return name;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getDistanceKm() {
        return distanceKm;
    }
}
