package com.example.fuelmilage.activities;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fuelmilage.R;
import com.example.fuelmilage.database.FuelRepository;
import com.example.fuelmilage.databinding.ActivityAddEditFuelEntryBinding;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.utils.FormatUtils;

import java.util.Calendar;
import java.util.Locale;

/**
 * Form to add a new fill-up or edit an existing record. Auto-calculates total cost from
 * litres × price unless the user overrides the total field.
 */
public class AddEditFuelEntryActivity extends AppCompatActivity {

    public static final String EXTRA_ENTRY_ID = "entry_id";

    private ActivityAddEditFuelEntryBinding binding;
    private FuelRepository repository;
    private long entryId = -1L;
    private long selectedDateMillis;
    private boolean suppressTotalWatcher;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityAddEditFuelEntryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        repository = FuelRepository.get(this);

        if (getIntent() != null && getIntent().hasExtra(EXTRA_ENTRY_ID)) {
            entryId = getIntent().getLongExtra(EXTRA_ENTRY_ID, -1L);
        }

        Calendar cal = Calendar.getInstance();
        selectedDateMillis = cal.getTimeInMillis();

        binding.fieldDate.setText(FormatUtils.formatDate(selectedDateMillis));
        binding.fieldDate.setOnClickListener(v -> showDatePicker());

        TextWatcher costSync = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (suppressTotalWatcher) {
                    return;
                }
                recalculateTotalFromUnitPrice();
            }
        };
        binding.inputLitres.getEditText().addTextChangedListener(costSync);
        binding.inputPricePerLitre.getEditText().addTextChangedListener(costSync);

        binding.inputTotalCost.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Manual total edits are respected; no auto overwrite while typing here.
            }
        });

        binding.buttonSave.setOnClickListener(v -> attemptSave());

        if (entryId > 0) {
            binding.toolbar.setTitle(R.string.title_edit_entry);
            loadExisting(entryId);
        } else {
            binding.toolbar.setTitle(R.string.title_add_entry);
        }
    }

    private void loadExisting(long id) {
        repository.getById(id, entry -> {
            if (entry == null) {
                Toast.makeText(this, R.string.error_entry_missing, Toast.LENGTH_LONG).show();
                finish();
                return;
            }
            selectedDateMillis = entry.getDateMillis();
            binding.fieldDate.setText(FormatUtils.formatDate(selectedDateMillis));
            binding.inputLitres.getEditText().setText(String.format(Locale.getDefault(), "%.2f", entry.getLitres()));
            binding.inputPricePerLitre.getEditText().setText(String.format(Locale.getDefault(), "%.3f", entry.getPricePerLitre()));
            suppressTotalWatcher = true;
            binding.inputTotalCost.getEditText().setText(String.format(Locale.getDefault(), "%.2f", entry.getTotalCost()));
            suppressTotalWatcher = false;
            binding.inputOdometer.getEditText().setText(String.format(Locale.getDefault(), "%.0f", entry.getOdometerKm()));
        });
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(selectedDateMillis);
        new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    Calendar picked = Calendar.getInstance();
                    picked.set(year, month, dayOfMonth, 12, 0, 0);
                    picked.set(Calendar.MILLISECOND, 0);
                    selectedDateMillis = picked.getTimeInMillis();
                    binding.fieldDate.setText(FormatUtils.formatDate(selectedDateMillis));
                },
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH),
                c.get(Calendar.DAY_OF_MONTH))
                .show();
    }

    private void recalculateTotalFromUnitPrice() {
        Double litres = parseDouble(binding.inputLitres.getEditText().getText().toString());
        Double price = parseDouble(binding.inputPricePerLitre.getEditText().getText().toString());
        if (litres != null && price != null && litres > 0 && price >= 0) {
            suppressTotalWatcher = true;
            binding.inputTotalCost.getEditText().setText(String.format(Locale.getDefault(), "%.2f", litres * price));
            suppressTotalWatcher = false;
        }
    }

    private void attemptSave() {
        Double litres = parseDouble(binding.inputLitres.getEditText().getText().toString());
        Double price = parseDouble(binding.inputPricePerLitre.getEditText().getText().toString());
        Double total = parseDouble(binding.inputTotalCost.getEditText().getText().toString());
        Double odometer = parseDouble(binding.inputOdometer.getEditText().getText().toString());

        if (litres == null || litres <= 0) {
            binding.inputLitres.setError(getString(R.string.error_invalid_litres));
            return;
        }
        if (price == null || price < 0) {
            binding.inputPricePerLitre.setError(getString(R.string.error_invalid_price));
            return;
        }
        if (total == null || total < 0) {
            binding.inputTotalCost.setError(getString(R.string.error_invalid_total));
            return;
        }
        if (odometer == null || odometer <= 0) {
            binding.inputOdometer.setError(getString(R.string.error_invalid_odometer));
            return;
        }

        final double litresVal = litres;
        final double priceVal = price;
        final double totalVal = total;
        final double odo = odometer;

        Runnable proceedSave = () -> {
            FuelEntry entry = new FuelEntry();
            if (entryId > 0) {
                entry.setId(entryId);
            }
            entry.setDateMillis(selectedDateMillis);
            entry.setLitres(litresVal);
            entry.setPricePerLitre(priceVal);
            entry.setTotalCost(totalVal);
            entry.setOdometerKm(odo);

            if (entryId > 0) {
                repository.update(entry, () -> runOnUiThread(() -> {
                    setResult(RESULT_OK);
                    finish();
                }));
            } else {
                repository.insert(entry, id -> runOnUiThread(() -> {
                    setResult(RESULT_OK);
                    finish();
                }));
            }
        };

        if (entryId > 0) {
            repository.getMaxOdometerExcluding(entryId, maxOther -> {
                if (maxOther != null && odo <= maxOther) {
                    runOnUiThread(() -> Toast.makeText(
                            this,
                            getString(R.string.error_odometer_not_greater, maxOther),
                            Toast.LENGTH_LONG).show());
                    return;
                }
                proceedSave.run();
            });
        } else {
            repository.getMaxOdometer(max -> {
                if (max != null && odo <= max) {
                    runOnUiThread(() -> Toast.makeText(
                            this,
                            getString(R.string.error_odometer_not_greater, max),
                            Toast.LENGTH_LONG).show());
                    return;
                }
                proceedSave.run();
            });
        }
    }

    @Nullable
    private static Double parseDouble(String raw) {
        if (raw == null) {
            return null;
        }
        String t = raw.trim().replace(',', '.');
        if (t.isEmpty()) {
            return null;
        }
        try {
            return Double.parseDouble(t);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
