package com.example.fuelmilage.utils;

import com.example.fuelmilage.models.AnalysisInsight;
import com.example.fuelmilage.models.FuelEntryDisplay;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

/**
 * Rule-based "AI" fuel usage analysis — compares recent vs older mileage and spend.
 */
public final class FuelAnalysisEngine {

    private FuelAnalysisEngine() {
    }

    public static AnalysisInsight analyze(List<FuelEntryDisplay> rows) {
        if (rows == null || rows.size() < 2) {
            return new AnalysisInsight(
                    "Getting started",
                    "Add more fill-ups to unlock personalized fuel insights.",
                    50);
        }

        List<FuelEntryDisplay> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparingLong(a -> a.getEntry().getDateMillis()));

        int score = computeEfficiencyScore(sorted);
        String title = "Fuel efficiency score";
        StringBuilder msg = new StringBuilder();

        double weekAgo = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000;
        double recentAvg = averageMileageSince(sorted, weekAgo);
        double olderAvg = averageMileageBefore(sorted, weekAgo);

        if (recentAvg > 0 && olderAvg > 0) {
            double delta = recentAvg - olderAvg;
            if (delta < -0.8) {
                msg.append("Your mileage decreased this week. Check tire pressure and air filters.\n");
            } else if (delta > 0.5) {
                msg.append("Great job — mileage improved this week.\n");
            }
        }

        if (MileageCalculator.hasMileageDropWarning(rows)) {
            msg.append("Reduce sudden acceleration and maintain steady speeds to save fuel.\n");
        }

        double spend30 = spendSince(sorted, System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000);
        if (spend30 > 0 && spend30 > estimateMonthlyBudget(sorted) * 1.2) {
            msg.append("Fuel spending is higher than usual — consider planning fill-ups.\n");
        }

        if (msg.length() == 0) {
            msg.append("Your driving and fuel patterns look stable. Keep logging fill-ups.");
        }

        return new AnalysisInsight(title, msg.toString().trim(), score);
    }

    private static int computeEfficiencyScore(List<FuelEntryDisplay> sorted) {
        double avg = MileageCalculator.averageMileage(sorted);
        if (avg <= 0) {
            return 55;
        }
        int base = (int) Math.min(100, Math.max(20, avg * 6));
        if (MileageCalculator.hasMileageDropWarning(sorted)) {
            base -= 12;
        }
        return Math.max(10, Math.min(100, base));
    }

    private static double averageMileageSince(List<FuelEntryDisplay> sorted, double sinceMillis) {
        double sum = 0;
        int n = 0;
        for (FuelEntryDisplay d : sorted) {
            if (d.getEntry().getDateMillis() >= sinceMillis && d.getMileageKmPerLitre() > 0) {
                sum += d.getMileageKmPerLitre();
                n++;
            }
        }
        return n == 0 ? 0 : sum / n;
    }

    private static double averageMileageBefore(List<FuelEntryDisplay> sorted, double beforeMillis) {
        double sum = 0;
        int n = 0;
        for (FuelEntryDisplay d : sorted) {
            if (d.getEntry().getDateMillis() < beforeMillis && d.getMileageKmPerLitre() > 0) {
                sum += d.getMileageKmPerLitre();
                n++;
            }
        }
        return n == 0 ? 0 : sum / n;
    }

    private static double spendSince(List<FuelEntryDisplay> sorted, double sinceMillis) {
        double total = 0;
        for (FuelEntryDisplay d : sorted) {
            if (d.getEntry().getDateMillis() >= sinceMillis) {
                total += d.getEntry().getTotalCost();
            }
        }
        return total;
    }

    private static double estimateMonthlyBudget(List<FuelEntryDisplay> sorted) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MONTH, -3);
        long since = c.getTimeInMillis();
        double total = 0;
        int months = 0;
        for (FuelEntryDisplay d : sorted) {
            if (d.getEntry().getDateMillis() >= since) {
                total += d.getEntry().getTotalCost();
            }
        }
        months = 3;
        return months == 0 ? 0 : total / months;
    }
}
