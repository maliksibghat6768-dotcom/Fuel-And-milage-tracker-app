package com.example.fuelmilage.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.fuelmilage.models.DrivingSession;

import java.util.List;

@Dao
public interface DrivingSessionDao {

    @Query("SELECT * FROM driving_sessions WHERE vehicleId = :vehicleId ORDER BY dateMillis DESC")
    LiveData<List<DrivingSession>> observeByVehicle(long vehicleId);

    @Query("SELECT * FROM driving_sessions WHERE vehicleId = :vehicleId ORDER BY dateMillis DESC LIMIT 30")
    List<DrivingSession> getRecent(long vehicleId);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(DrivingSession session);

    @Update
    void update(DrivingSession session);

    @Delete
    void delete(DrivingSession session);
}
