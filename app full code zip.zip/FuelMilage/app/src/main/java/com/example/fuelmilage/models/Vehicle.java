package com.example.fuelmilage.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/** User vehicle profile for multi-vehicle tracking. */
@Entity(tableName = "vehicles")
public class Vehicle {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private String name;
    private String model;
    /** e.g. Petrol, Diesel, CNG */
    private String fuelType;
    private boolean active;
    /** Cloud sync marker */
    private long updatedAtMillis;

    public Vehicle() {
    }

    @Ignore
    public Vehicle(String name, String model, String fuelType) {
        this.name = name;
        this.model = model;
        this.fuelType = fuelType;
        this.active = false;
        this.updatedAtMillis = System.currentTimeMillis();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public void setUpdatedAtMillis(long updatedAtMillis) {
        this.updatedAtMillis = updatedAtMillis;
    }
}
