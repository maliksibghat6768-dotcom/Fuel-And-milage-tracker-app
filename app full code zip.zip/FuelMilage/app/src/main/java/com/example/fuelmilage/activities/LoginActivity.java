package com.example.fuelmilage.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.fuelmilage.databinding.ActivityLoginBinding;
import com.example.fuelmilage.firebase.FirebaseAuthHelper;
import com.example.fuelmilage.utils.AppPreferences;

/**
 * Email login/registration with optional offline mode.
 */
public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private FirebaseAuthHelper authHelper;
    private AppPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new AppPreferences(this);
        if (prefs.isSkipLogin() || new FirebaseAuthHelper(this).isLoggedIn()) {
            openMain();
            return;
        }

        EdgeToEdge.enable(this);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        authHelper = new FirebaseAuthHelper(this);

        binding.buttonLogin.setOnClickListener(v -> attemptLogin());
        binding.buttonRegister.setOnClickListener(v -> attemptRegister());
        binding.buttonOffline.setOnClickListener(v -> {
            prefs.setSkipLogin(true);
            openMain();
        });
    }

    private void attemptLogin() {
        String email = text(binding.inputEmail);
        String password = text(binding.inputPassword);
        if (email.isEmpty() || password.length() < 6) {
            Toast.makeText(this, com.example.fuelmilage.R.string.auth_invalid, Toast.LENGTH_LONG).show();
            return;
        }
        authHelper.login(email, password, new FirebaseAuthHelper.AuthCallback() {
            @Override
            public void onSuccess() {
                openMain();
            }

            @Override
            public void onError(String message) {
                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void attemptRegister() {
        String email = text(binding.inputEmail);
        String password = text(binding.inputPassword);
        if (email.isEmpty() || password.length() < 6) {
            Toast.makeText(this, com.example.fuelmilage.R.string.auth_invalid, Toast.LENGTH_LONG).show();
            return;
        }
        authHelper.register(email, password, new FirebaseAuthHelper.AuthCallback() {
            @Override
            public void onSuccess() {
                openMain();
            }

            @Override
            public void onError(String message) {
                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private static String text(com.google.android.material.textfield.TextInputLayout layout) {
        return layout.getEditText() != null && layout.getEditText().getText() != null
                ? layout.getEditText().getText().toString().trim()
                : "";
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
