package com.example.fuelmilage.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/**
 * Scheduled maintenance reminder (oil, engine, tires, brakes).
 * Types: {@link #TYPE_OIL}, {@link #TYPE_ENGINE}, {@link #TYPE_TIRE}, {@link #TYPE_BRAKE}
 */
@Entity(tableName = "maintenance_items")
public class MaintenanceItem {

    public static final String TYPE_OIL = "OIL_CHANGE";
    public static final String TYPE_ENGINE = "ENGINE_SERVICE";
    public static final String TYPE_TIRE = "TIRE_CHECK";
    public static final String TYPE_BRAKE = "BRAKE_INSPECTION";

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long vehicleId;
    private String type;
    private String title;
    /** Last service odometer in km */
    private double lastOdometerKm;
    /** Repeat every N km */
    private int intervalKm;
    /** Optional calendar reminder */
    private long nextDueDateMillis;
    private boolean enabled;
    private long updatedAtMillis;

    public MaintenanceItem() {
    }

    @Ignore
    public MaintenanceItem(long vehicleId, String type, String title,
                         double lastOdometerKm, int intervalKm, long nextDueDateMillis) {
        this.vehicleId = vehicleId;
        this.type = type;
        this.title = title;
        this.lastOdometerKm = lastOdometerKm;
        this.intervalKm = intervalKm;
        this.nextDueDateMillis = nextDueDateMillis;
        this.enabled = true;
        this.updatedAtMillis = System.currentTimeMillis();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(long vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getLastOdometerKm() {
        return lastOdometerKm;
    }

    public void setLastOdometerKm(double lastOdometerKm) {
        this.lastOdometerKm = lastOdometerKm;
    }

    public int getIntervalKm() {
        return intervalKm;
    }

    public void setIntervalKm(int intervalKm) {
        this.intervalKm = intervalKm;
    }

    public long getNextDueDateMillis() {
        return nextDueDateMillis;
    }

    public void setNextDueDateMillis(long nextDueDateMillis) {
        this.nextDueDateMillis = nextDueDateMillis;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public void setUpdatedAtMillis(long updatedAtMillis) {
        this.updatedAtMillis = updatedAtMillis;
    }
}
