package com.example.fuelmilage.models;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/** Recorded trip with distance, fuel, cost, and duration. */
@Entity(tableName = "trips")
public class Trip {

    @PrimaryKey(autoGenerate = true)
    private long id;
    private long vehicleId;
    private String title;
    private long startMillis;
    private long endMillis;
    private double distanceKm;
    private double fuelLitres;
    private double cost;
    private int durationMinutes;
    private long updatedAtMillis;

    public Trip() {
    }

    @Ignore
    public Trip(long vehicleId, String title, long startMillis, long endMillis,
                double distanceKm, double fuelLitres, double cost, int durationMinutes) {
        this.vehicleId = vehicleId;
        this.title = title;
        this.startMillis = startMillis;
        this.endMillis = endMillis;
        this.distanceKm = distanceKm;
        this.fuelLitres = fuelLitres;
        this.cost = cost;
        this.durationMinutes = durationMinutes;
        this.updatedAtMillis = System.currentTimeMillis();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(long vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public long getStartMillis() {
        return startMillis;
    }

    public void setStartMillis(long startMillis) {
        this.startMillis = startMillis;
    }

    public long getEndMillis() {
        return endMillis;
    }

    public void setEndMillis(long endMillis) {
        this.endMillis = endMillis;
    }

    public double getDistanceKm() {
        return distanceKm;
    }

    public void setDistanceKm(double distanceKm) {
        this.distanceKm = distanceKm;
    }

    public double getFuelLitres() {
        return fuelLitres;
    }

    public void setFuelLitres(double fuelLitres) {
        this.fuelLitres = fuelLitres;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public long getUpdatedAtMillis() {
        return updatedAtMillis;
    }

    public void setUpdatedAtMillis(long updatedAtMillis) {
        this.updatedAtMillis = updatedAtMillis;
    }
}
