package com.example.fuelmilage.adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fuelmilage.databinding.ItemPetrolPumpBinding;
import com.example.fuelmilage.maps.PetrolPumpFinder;
import com.example.fuelmilage.models.PetrolPump;

import java.util.ArrayList;
import java.util.List;

public class PetrolPumpAdapter extends RecyclerView.Adapter<PetrolPumpAdapter.Holder> {

    public interface Listener {
        void onDirections(PetrolPump pump);
    }

    private final Listener listener;
    private List<PetrolPump> items = new ArrayList<>();

    public PetrolPumpAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<PetrolPump> pumps) {
        items = pumps != null ? pumps : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemPetrolPumpBinding binding = ItemPetrolPumpBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new Holder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        holder.bind(items.get(position));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class Holder extends RecyclerView.ViewHolder {
        private final ItemPetrolPumpBinding binding;

        Holder(ItemPetrolPumpBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(PetrolPump pump) {
            binding.textName.setText(pump.getName());
            binding.textDistance.setText(PetrolPumpFinder.formatDistance(pump.getDistanceKm()));
            binding.buttonDirections.setOnClickListener(v -> listener.onDirections(pump));
        }
    }
}
