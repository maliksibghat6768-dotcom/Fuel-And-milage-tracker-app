package com.example.fuelmilage.services;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.fuelmilage.firebase.CloudSyncRepository;
import com.example.fuelmilage.utils.NetworkUtils;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Background worker that syncs local SQLite data to Firebase when online.
 */
public class SyncWorker extends Worker {

    public SyncWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        if (!NetworkUtils.isOnline(getApplicationContext())) {
            return Result.retry();
        }
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean ok = new AtomicBoolean(false);
        new CloudSyncRepository(getApplicationContext()).syncIfPossible((success, message) -> {
            ok.set(success);
            latch.countDown();
        });
        try {
            latch.await(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            return Result.retry();
        }
        // Do not retry indefinitely when Firebase is not configured or user is logged out.
        return Result.success();
    }
}
