package com.example.fuelmilage.utils;

import com.example.fuelmilage.models.FuelPriceInfo;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Fetches fuel prices from mock JSON asset, with optional remote URL override.
 */
public class FuelPriceService {

    public interface Callback {
        void onResult(FuelPriceInfo info);

        void onError(String message);
    }

    private static final String MOCK_ASSET = "mock_fuel_prices.json";
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    public void fetch(android.content.Context context, Callback callback) {
        IO.execute(() -> {
            try {
                FuelPriceInfo info = loadFromAsset(context);
                if (info != null) {
                    callback.onResult(info);
                    return;
                }
            } catch (Exception ignored) {
            }
            try {
                FuelPriceInfo remote = loadRemote();
                if (remote != null) {
                    callback.onResult(remote);
                } else {
                    callback.onError("Unable to load prices");
                }
            } catch (Exception e) {
                callback.onError(e.getMessage() != null ? e.getMessage() : "Network error");
            }
        });
    }

    private FuelPriceInfo loadFromAsset(android.content.Context context) throws Exception {
        InputStream in = context.getAssets().open(MOCK_ASSET);
        String json = readStream(in);
        return parse(json);
    }

  private FuelPriceInfo loadRemote() throws Exception {
        // Replace with your real API endpoint when available.
        String endpoint = "https://example.com/api/fuel-prices";
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setConnectTimeout(4000);
        conn.setReadTimeout(4000);
        conn.setRequestMethod("GET");
        if (conn.getResponseCode() != 200) {
            return null;
        }
        String json = readStream(conn.getInputStream());
        return parse(json);
    }

    private static FuelPriceInfo parse(String json) throws Exception {
        JSONObject o = new JSONObject(json);
        double petrol = o.optDouble("petrol", 1.45);
        double diesel = o.optDouble("diesel", 1.38);
        long updated = o.optLong("updatedAtMillis", System.currentTimeMillis());
        String region = o.optString("region", "National average");
        return new FuelPriceInfo(petrol, diesel, updated, region);
    }

    private static String readStream(InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line);
            }
        }
        return sb.toString();
    }
}
