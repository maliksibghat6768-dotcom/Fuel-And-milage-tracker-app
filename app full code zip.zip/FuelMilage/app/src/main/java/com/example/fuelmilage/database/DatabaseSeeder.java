package com.example.fuelmilage.database;

import com.example.fuelmilage.models.MaintenanceItem;
import com.example.fuelmilage.models.Vehicle;

/**
 * Seeds default vehicle and maintenance templates on first launch.
 */
public final class DatabaseSeeder {

    private DatabaseSeeder() {
    }

    public static void ensureDefaults(AppDatabase db) {
        if (db.vehicleDao().count() > 0) {
            return;
        }
        Vehicle v = new Vehicle("My Car", "Sedan", "Petrol");
        v.setActive(true);
        long vehicleId = db.vehicleDao().insert(v);
        seedMaintenance(db, vehicleId);
    }

    private static void seedMaintenance(AppDatabase db, long vehicleId) {
        db.maintenanceDao().insert(new MaintenanceItem(
                vehicleId, MaintenanceItem.TYPE_OIL, "Oil change", 0, 5000, 0));
        db.maintenanceDao().insert(new MaintenanceItem(
                vehicleId, MaintenanceItem.TYPE_ENGINE, "Engine service", 0, 15000, 0));
        db.maintenanceDao().insert(new MaintenanceItem(
                vehicleId, MaintenanceItem.TYPE_TIRE, "Tire check", 0, 8000, 0));
        db.maintenanceDao().insert(new MaintenanceItem(
                vehicleId, MaintenanceItem.TYPE_BRAKE, "Brake inspection", 0, 12000, 0));
    }
}
