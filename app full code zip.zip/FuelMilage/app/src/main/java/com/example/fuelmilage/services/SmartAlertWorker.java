package com.example.fuelmilage.services;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.example.fuelmilage.database.AppDatabase;
import com.example.fuelmilage.models.FuelEntry;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.models.MaintenanceItem;
import com.example.fuelmilage.notifications.NotificationHelper;
import com.example.fuelmilage.R;
import com.example.fuelmilage.utils.AppPreferences;
import com.example.fuelmilage.utils.MileageCalculator;

import java.util.List;

/**
 * Periodic checks for low mileage, refill reminders, maintenance, and high spend.
 */
public class SmartAlertWorker extends Worker {

    public SmartAlertWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        AppPreferences prefs = new AppPreferences(ctx);
        long vehicleId = prefs.getActiveVehicleId();
        List<FuelEntry> fuel = AppDatabase.getInstance(ctx).fuelEntryDao().getByVehicle(vehicleId);
        List<FuelEntryDisplay> rows = MileageCalculator.buildDisplayList(fuel);

        if (prefs.isNotifyLowMileage() && MileageCalculator.hasMileageDropWarning(rows)) {
            NotificationHelper.show(ctx, 1001,
                    ctx.getString(R.string.notify_low_mileage_title),
                    ctx.getString(R.string.notify_low_mileage_body));
        }

        if (prefs.isNotifyRefill() && shouldRemindRefill(fuel, prefs.getRefillIntervalDays())) {
            NotificationHelper.show(ctx, 1002,
                    ctx.getString(R.string.notify_refill_title),
                    ctx.getString(R.string.notify_refill_body));
        }

        if (prefs.isNotifyHighSpend() && isHighSpend(fuel)) {
            NotificationHelper.show(ctx, 1003,
                    ctx.getString(R.string.notify_high_spend_title),
                    ctx.getString(R.string.notify_high_spend_body));
        }

        if (prefs.isNotifyMaintenance()) {
            checkMaintenance(ctx, vehicleId, fuel);
        }
        return Result.success();
    }

    private void checkMaintenance(Context ctx, long vehicleId, List<FuelEntry> fuel) {
        double maxOdo = 0;
        if (fuel != null) {
            for (FuelEntry e : fuel) {
                maxOdo = Math.max(maxOdo, e.getOdometerKm());
            }
        }
        List<MaintenanceItem> items = AppDatabase.getInstance(ctx)
                .maintenanceDao().getEnabled(vehicleId);
        for (MaintenanceItem item : items) {
            double next = item.getLastOdometerKm() + item.getIntervalKm();
            if (maxOdo > 0 && next - maxOdo <= 500) {
                NotificationHelper.show(ctx, 2000 + (int) item.getId(),
                        ctx.getString(R.string.notify_maint_title),
                        ctx.getString(R.string.notify_maint_body, item.getTitle()));
            }
        }
    }

    private static boolean shouldRemindRefill(List<FuelEntry> fuel, int intervalDays) {
        if (fuel == null || fuel.isEmpty()) {
            return false;
        }
        long latest = 0;
        for (FuelEntry e : fuel) {
            latest = Math.max(latest, e.getDateMillis());
        }
        long days = (System.currentTimeMillis() - latest) / (24L * 60 * 60 * 1000);
        return days >= intervalDays;
    }

    private static boolean isHighSpend(List<FuelEntry> fuel) {
        if (fuel == null) {
            return false;
        }
        long since = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000;
        double total = 0;
        for (FuelEntry e : fuel) {
            if (e.getDateMillis() >= since) {
                total += e.getTotalCost();
            }
        }
        return total > 500;
    }
}
