package com.example.fuelmilage.database;

import android.content.Context;

/**
 * Thin facade over {@link AppDatabase} for a familiar “database helper” entry point.
 * Persistence is implemented with Room; this class simply exposes the singleton.
 */
public class FuelDatabaseHelper {

    private FuelDatabaseHelper() {
    }

    public static AppDatabase getDatabase(Context context) {
        return AppDatabase.getInstance(context);
    }
}
