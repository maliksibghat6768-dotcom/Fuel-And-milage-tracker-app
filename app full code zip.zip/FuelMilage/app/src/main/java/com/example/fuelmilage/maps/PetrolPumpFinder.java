package com.example.fuelmilage.maps;

import com.example.fuelmilage.models.PetrolPump;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Finds nearby petrol pumps. Uses demo offsets around GPS when Places API is not configured.
 */
public final class PetrolPumpFinder {

    private static final String[] DEMO_NAMES = {
            "City Fuel Station",
            "Highway Petrol Pump",
            "QuickFill Gas",
            "Metro Fuel Center",
            "Green Energy Petrol"
    };

    private PetrolPumpFinder() {
    }

    public static List<PetrolPump> findNearby(double lat, double lng) {
        List<PetrolPump> pumps = new ArrayList<>();
        double[][] offsets = {
                {0.008, 0.006},
                {-0.012, 0.004},
                {0.005, -0.015},
                {-0.007, -0.009},
                {0.018, 0.011}
        };
        for (int i = 0; i < DEMO_NAMES.length; i++) {
            double pLat = lat + offsets[i][0];
            double pLng = lng + offsets[i][1];
            double dist = haversineKm(lat, lng, pLat, pLng);
            pumps.add(new PetrolPump(DEMO_NAMES[i], pLat, pLng, dist));
        }
        Collections.sort(pumps, Comparator.comparingDouble(PetrolPump::getDistanceKm));
        return pumps;
    }

    /** Great-circle distance in kilometres. */
    public static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return r * c;
    }

    public static String formatDistance(double km) {
        if (km < 1) {
            return String.format(Locale.getDefault(), "%.0f m", km * 1000);
        }
        return String.format(Locale.getDefault(), "%.1f km", km);
    }
}
