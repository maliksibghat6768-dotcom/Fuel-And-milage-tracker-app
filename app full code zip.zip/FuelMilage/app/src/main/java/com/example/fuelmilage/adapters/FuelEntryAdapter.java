package com.example.fuelmilage.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fuelmilage.databinding.ItemFuelEntryBinding;
import com.example.fuelmilage.models.FuelEntryDisplay;
import com.example.fuelmilage.utils.FormatUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * RecyclerView adapter for fuel history with edit/delete actions.
 */
public class FuelEntryAdapter extends RecyclerView.Adapter<FuelEntryAdapter.VH> {

    public interface Listener {
        void onEdit(FuelEntryDisplay row);

        void onDelete(FuelEntryDisplay row);
    }

    private final List<FuelEntryDisplay> data = new ArrayList<>();
    private final Listener listener;

    public FuelEntryAdapter(Listener listener) {
        this.listener = listener;
    }

    public void submit(List<FuelEntryDisplay> rows) {
        data.clear();
        if (rows != null) {
            data.addAll(rows);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemFuelEntryBinding b = ItemFuelEntryBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new VH(b);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        FuelEntryDisplay row = data.get(position);
        holder.bind(row, listener);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        private final ItemFuelEntryBinding binding;

        VH(ItemFuelEntryBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(FuelEntryDisplay row, Listener listener) {
            binding.textDate.setText(FormatUtils.formatDate(row.getEntry().getDateMillis()));
            binding.textLitres.setText(FormatUtils.formatLitres(row.getEntry().getLitres()));
            binding.textCost.setText(FormatUtils.formatCurrency(row.getEntry().getTotalCost()));
            binding.textMileage.setText(FormatUtils.formatMileage(row.getMileageKmPerLitre()));
            binding.textOdometer.setText(FormatUtils.formatOdometer(row.getEntry().getOdometerKm()));

            binding.buttonEdit.setOnClickListener(v -> listener.onEdit(row));
            binding.buttonDelete.setOnClickListener(v -> listener.onDelete(row));
        }
    }
}
