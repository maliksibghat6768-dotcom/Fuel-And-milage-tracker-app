package com.example.fuelmilage.activities;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.fuelmilage.R;
import com.example.fuelmilage.adapters.PetrolPumpAdapter;
import com.example.fuelmilage.databinding.ActivityMapsBinding;
import com.example.fuelmilage.maps.MapsIntentHelper;
import com.example.fuelmilage.maps.PetrolPumpFinder;
import com.example.fuelmilage.models.PetrolPump;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * GPS map with nearby petrol pumps, distances, and directions intent.
 */
public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback, PetrolPumpAdapter.Listener {

    private static final int REQ_LOCATION = 42;

    private ActivityMapsBinding binding;
    private GoogleMap googleMap;
    private FusedLocationProviderClient fusedLocation;
    private final Map<Marker, PetrolPump> markerPumpMap = new HashMap<>();
    private PetrolPumpAdapter adapter;
    private double userLat;
    private double userLng;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            return insets;
        });

        setSupportActionBar(binding.toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
        binding.toolbar.setNavigationOnClickListener(v -> finish());

        fusedLocation = LocationServices.getFusedLocationProviderClient(this);
        adapter = new PetrolPumpAdapter(this);
        binding.recyclerPumps.setLayoutManager(new LinearLayoutManager(this));
        binding.recyclerPumps.setAdapter(adapter);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map_fragment);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        googleMap.getUiSettings().setZoomControlsEnabled(true);
        googleMap.setOnMarkerClickListener(marker -> {
            PetrolPump pump = markerPumpMap.get(marker);
            if (pump != null) {
                openDirections(pump);
            }
            return true;
        });
        enableMyLocation();
    }

    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQ_LOCATION);
            return;
        }
        if (googleMap != null) {
            try {
                googleMap.setMyLocationEnabled(true);
            } catch (SecurityException ignored) {
            }
        }
        loadLocation();
    }

    private void loadLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocation.getLastLocation().addOnSuccessListener(this::onLocationReady);
    }

    private void onLocationReady(Location location) {
        if (location == null) {
            userLat = 28.6139;
            userLng = 77.2090;
            Toast.makeText(this, R.string.maps_location_default, Toast.LENGTH_SHORT).show();
        } else {
            userLat = location.getLatitude();
            userLng = location.getLongitude();
        }
        LatLng user = new LatLng(userLat, userLng);
        if (googleMap != null) {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(user, 13f));
            showPumps();
        }
    }

    private void showPumps() {
        List<PetrolPump> pumps = PetrolPumpFinder.findNearby(userLat, userLng);
        adapter.submit(pumps);
        markerPumpMap.clear();
        if (googleMap == null) {
            return;
        }
        googleMap.clear();
        for (PetrolPump pump : pumps) {
            LatLng pos = new LatLng(pump.getLatitude(), pump.getLongitude());
            Marker marker = googleMap.addMarker(new MarkerOptions()
                    .position(pos)
                    .title(pump.getName())
                    .snippet(PetrolPumpFinder.formatDistance(pump.getDistanceKm()))
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)));
            if (marker != null) {
                markerPumpMap.put(marker, pump);
            }
        }
    }

    @Override
    public void onDirections(PetrolPump pump) {
        openDirections(pump);
    }

    private void openDirections(PetrolPump pump) {
        Intent nav = MapsIntentHelper.directionsIntent(pump.getLatitude(), pump.getLongitude());
        if (nav.resolveActivity(getPackageManager()) != null) {
            startActivity(nav);
        } else {
            startActivity(MapsIntentHelper.fallbackBrowserDirections(
                    this, pump.getLatitude(), pump.getLongitude()));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            enableMyLocation();
        }
    }
}
